<?php
require_once('db.php');
$category_id = mysql_real_escape_string($_POST['category_id']);
if($category_id!='')
{
	$states_result = $conn->query('select * from tbl_asset_type where category_id='.$category_id.'');
	$options = "<option value=''>Select Asset Type</option>";
	while($row = $states_result->fetch_assoc()) {
	$options .= "<option value='".$row['asset_type_id']."'>".$row['type_name']."</option>";
	}
	echo $options;
}

?>