
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
        <script type="text/javascript" src="dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body> 
</html>
<?php
include 'connect.php';
 $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
       date_default_timezone_set("Asia/Manila");
      if ($_FILES['file_uploaded']['name'] !== "")
      {
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $calibration_id= isset($_POST['calibration_idz'])? $_POST['calibration_idz']:"";
      $uploaded_date  = date("Y-m-d");  
      $equipment_id = $_POST["equipment_id"];
      $report_name = $_POST["report_name"];
      $report_description = $_POST["report_description"];
      $status = $_POST["status"];
     
   $pname = rand(1000,10000)."-".$_FILES["file_uploaded"]["name"];
 
    #temporary file name to store file
    $tname = $_FILES["file_uploaded"]["tmp_name"];

   $uploads_dir = 'Uploaded Files';
    #TO move the uploaded file to specific location
    move_uploaded_file($tname, $uploads_dir.'/'.$pname);
 
      $query = ("UPDATE tbl_calibration_report SET equipment_id='".$equipment_id."', report_name='".$report_name."', report_description='".$report_description."', file_uploaded='".$pname."', uploaded_date='".$uploaded_date."', status='".$status."', user_id='".$user_id."' WHERE calibration_id = '".$calibration_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
        error2();
      }
      }
      else
      {
       date_default_timezone_set("Asia/Manila");
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $calibration_id= isset($_POST['calibration_idz'])? $_POST['calibration_idz']:"";
      $uploaded_date  = date("Y-m-d");  
      $equipment_id = $_POST["equipment_id"];
      $report_name = $_POST["report_name"];

      $report_description = $_POST["report_description"];
      $status = $_POST["status"];
      $query = ("UPDATE tbl_calibration_report SET equipment_id='".$equipment_id."', report_name='".$report_name."', report_description='".$report_description."', uploaded_date='".$uploaded_date."', status='".$status."', user_id='".$user_id."' WHERE calibration_id = '".$calibration_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
        error2();
      }
      }
  function succ()
    {
      echo '<script>
      swal({
        title: "Updated Successfully",
        type: "success",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "calibrationreport_pending.php ";
      });
      </script>';
    }
    function error2()
    {
      echo '<script>
      swal({
        title: "Error!!!..",
        type: "error",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "calibrationreport_pending.php ";
      });
      </script>';
    }  
 ?>  
