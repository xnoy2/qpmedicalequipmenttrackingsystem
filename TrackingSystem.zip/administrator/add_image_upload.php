  <!DOCTYPE html>
<html>
  <head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
    <script type="text/javascript" src="dist/sweetalert-dev.js"></script>
  </head>
  

  <body>
    
  </body>

</html>

   
  <?php  
 $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");  
      $equipment_id = $_POST['equipment_id'];  
      $image_name = $_POST['image_name'];  
      $description = $_POST['description'];  
      $image_file = addslashes(file_get_contents($_FILES["image_file"]["tmp_name"]));
      
            $query = "INSERT INTO tbl_images(equipment_id,image_name,image_file,description) VALUES ('$equipment_id','$image_name','$image_file','$description')";  
      if(mysqli_query($connect, $query))  
      {  
       succ();
     }
    else
  {
  error2();
}
  function succ()
    {
      echo '<script>
      swal({
        title: "Added Successfully",
        type: "success",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "imageupload.php ";
      });
      </script>';
    }
    function error2()
    {
      echo '<script>
      swal({
        title: "Error!!!..",
        type: "error",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "imageupload.php ";
      });
      </script>';
    }  
 ?>  
