
<?php
  require_once("connect.php");
  date_default_timezone_set("Asia/Manila");
  $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");  
  $sql="SELECT tbl_images.image_id, tbl_images.equipment_id, tbl_medical_equipment.equipment_name, tbl_images.image_name, tbl_images.image_file, tbl_images.description
FROM tbl_medical_equipment INNER JOIN tbl_images ON tbl_medical_equipment.equipment_id = tbl_images.equipment_id;
";
$qry=$DbConnect->prepare($sql);
$qry->bind_result($image_id,$equipment_id,$equipment_name,$image_name,$image_file,$description);
$qry->execute();
$result = mysqli_query($connect, $sql);  
while($row = mysqli_fetch_array($result))
  { 
    ?>

      <tr>
      
        <td><b style="color: blue;"><?php printf ("%s", $row["equipment_name"]); ?> </b></td>
        <td><i><?php printf ("%s", $row["image_name"]); ?></i></td>
        <?php echo '<td style="width: 13%;"><center> <img src="data:image/jpeg;base64,'.base64_encode($row['image_file'] ).'" height="50" width="50" class="img-square elevation-2" alt="User Image" /> </center></td>'; ?> 
        <td><?php printf ("%s", $row["description"]); ?> </td>
         <td>

        <button type='button' class='btn btn-info btn-xs' data-toggle='modal' data-target='#update<?php printf ("%s", $row["image_id"]); ?>'><i class='fa fa-pencil-alt'></i> 
              </button>
          <button type='button' class='btn btn-xs btn-danger ' data-toggle='modal' data-target='#delete<?php printf ("%s", $row["image_id"]); ?>'><i class="fa fa-trash "></i>  </button>
        </td>
              
      </tr>
      
               <div class="modal fade" id="update<?php printf ("%s", $row["image_id"]); ?>">
                        <div class="modal-dialog modal-sm">
                            <form action="update_image.php" method="post" id="form1<?php printf ("%s", $row["image_id"]); ?>" name="form1" enctype="multipart/form-data">
                         <input type="hidden" name="image_idz" value="<?php printf ("%s", $row["image_id"]); ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Image Upload</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="row">
                                 <div class="col-12">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Equipment</label>
                                  <select class="form-control select2" name="equipment_id">
                                    <option selected="" value="<?php printf ("%s", $row["equipment_id"]); ?>"><?php printf ("%s", $row["equipment_name"]); ?></option>
                                    <?php
                                    include 'connect.php';
                                    $sql="SELECT tbl_medical_equipment.equipment_id,tbl_medical_equipment.equipment_name FROM tbl_medical_equipment WHERE tbl_medical_equipment.status = 'Approved' ORDER BY tbl_medical_equipment.equipment_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($equipment_id,$equipment_name);
                                    $qry->execute();
                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $equipment_id ?>"><?php echo $equipment_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-12">
                              <div class="form-group">
                                  <label for="exampleInputEmail1">Image Name</label>
                                  <input type="text" class="form-control"  name="image_name" id="" value="<?php printf ("%s", $row["image_name"]); ?>">
                                </div>
                              </div>
                                <div class="col-12">
                                <div class="form-group">
                                  <label for="exampleInputPassword1">Description</label>
                                  <textarea class="form-control" name="description" rows="4"><?php printf ("%s", $row["description"]); ?></textarea>
                                </div>
                              </div>
                              <div class="col-12">
                              <div class="form-group">
                                  <label for="exampleInputEmail1">Select New Image</label><p style="margin-left: 49%; margin-top: -12%; color: blue">(Optional)</p>
                                  <input type="file"  name="image_file" id="">
                                </div>
                              </div>
                              </div>
                            </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                              <button type="submit" onclick="form1<?php printf ("%s", $row["image_id"]); ?>.submit();" form="form1" class="btn btn-primary"><i class="fa fa-check"></i> Update</button>
                            </div>
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
          
                      <div class="modal fade" id="delete<?php printf ("%s", $row["image_id"]); ?>" style="margin-left: 30%; margin-top: 20%">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Are you sure you want delete this data?</h5>
              
            </div>
            
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> No!</button>
              <a href="delete_image.php? image_id=<?php printf ("%s", $row["image_id"]); ?>"><button type="button" class="btn btn-primary"><i class="fa fa-check"></i> Yes!</button></a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
         
        
          
<?php 
  }   
  
?>
