
<?php
  include 'connect.php';
  $user_id = $_SESSION['user_id'];
  $sql="SELECT tbl_vendor.vendor_id,tbl_vendor.vendor_name,tbl_vendor.vendor_address,tbl_vendor.vendor_contact,tbl_user.user_id,tbl_user.full_name FROM tbl_vendor INNER JOIN tbl_user ON tbl_vendor.user_id=tbl_user.user_id";
 $qry=$DbConnect->prepare($sql);
  $qry->bind_result($vendor_id,$vendor_name,$vendor_address,$vendor_contact,$user_id,$full_name);
    $qry->execute();
  while ($qry->fetch())
  {
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_id,full_name FROM tbl_user WHERE user_id=?";
      ?>

      <tr>
      
        <td><?php echo $vendor_name; ?> </td>
        <td><?php echo $vendor_address; ?> </td>
        <td><?php echo $vendor_contact; ?> </td>
        <td><?php echo $full_name; ?> </td>
         <td>
        <button type='button' class='btn btn-info btn-xs' data-toggle='modal' data-target='#update<?php echo $vendor_id; ?>'><i class='fa fa-pencil-alt'></i> 
              </button>
          <button type='button' class='btn btn-xs btn-danger ' data-toggle='modal' data-target='#delete<?php echo $vendor_id; ?>'><i class="fa fa-trash "></i>  </button>
        </td>
              
      </tr>
      
                  <div class="modal fade" id="update<?php echo $vendor_id;?>">
                        <div class="modal-dialog modal-sm">
                            <form action="update_vendor.php" method="post" id="form1<?php echo $vendor_id; ?>"  name="form1">
                         <input type="hidden" name="vendor_idz" value="<?php echo $vendor_id; ?>">
                         <input type="hidden" name="user_idz" value="<?php echo $user_id; ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Update Vendor</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Vendor</label>
                                  <input type="text" class="form-control" id="" name="vendor_name" value="<?php echo $vendor_name; ?>">
                                </div>
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Address</label>
                                  <input type="text" class="form-control" id="" name="vendor_address" value="<?php echo $vendor_address; ?>">
                                </div>
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Contact</label>
                                  <input type="text" class="form-control" id="" name="vendor_contact" value="<?php echo $vendor_contact; ?>">
                                </div>
                              </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                              <button type="submit" onclick="form1<?php echo $vendor_id; ?>.submit();" form="form1" class="btn btn-primary"><i class="fa fa-check"></i> Update</button>
                            </div>
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                      <div class="modal fade" id="delete<?php echo $vendor_id;?>" style="margin-left: 30%; margin-top: 20%">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Are you sure you want delete this data?</h5>
              
            </div>
            
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> No!</button>
              <a href="delete_vendor.php? vendor_id=<?php echo $vendor_id; ?>"><button type="button" class="btn btn-primary"><i class="fa fa-check"></i> Yes!</button></a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
         

        
          
<?php 
  }   
  
?>
