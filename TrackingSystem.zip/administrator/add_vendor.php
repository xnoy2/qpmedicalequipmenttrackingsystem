<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
		<script type="text/javascript" src="dist/sweetalert-dev.js"></script>
	</head>
	

	<body>
		
	</body>

</html>

 <?php
	include ("connect.php");

	$vendor_name = $_POST['vendor_name'];
	$vendor_address = $_POST['vendor_address'];
	$vendor_contact = $_POST['vendor_contact'];
	$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
		$sql1 = "SELECT * FROM tbl_vendor WHERE vendor_name=?";
			$qry1 =$DbConnect->prepare($sql1);
			$qry1->bind_param("s",$vendor_name);
			$qry1->execute();
			$qry1->store_result();
			$qry1->fetch();
			if ($qry1->num_rows()<=0)
				{
	if (!empty($vendor_name) && !empty($vendor_contact) && !empty($vendor_address))
		{
			$vendor_name = $_POST['vendor_name'];
			$vendor_address = $_POST['vendor_address'];
			$vendor_contact = $_POST['vendor_contact'];
			$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
			$sql="INSERT INTO tbl_vendor (vendor_name,vendor_address,vendor_contact,user_id) VALUES (?,?,?,?)";
			$qry=$DbConnect->prepare($sql);
			$qry->bind_param("ssss", $vendor_name,$vendor_address,$vendor_contact,$user_id);
			if ($qry->execute())
			{
				 succ();

			}
			else
		{
			error2();
		}
		}
		else
		{
			error2();
		}
	}
	else
	{
		err2();
	}
		function succ()
		{
			echo '<script>
			swal({
				title: "Added Successfully",
				type: "success",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "vendor.php ";
			});
			</script>';
		}
		function error2()
		{
			echo '<script>
			swal({
				title: "Error!!!..",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "vendor.php ";
			});
			</script>';
		}
				function err2()
		{
			echo '<script>
			swal({
				title: "Vendor name Already Exist",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "vendor.php ";
			});
			</script>';
		}
	
?>