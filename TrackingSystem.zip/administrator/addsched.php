<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
		<script type="text/javascript" src="dist/sweetalert-dev.js"></script>
	</head>
	

	<body>
		
	</body>

</html>

 <?php
	include ("connect.php");

	$remarks = $_POST['remarks'];
	$sched_date = $_POST['sched_date'];
	$equipment_id = $_POST['equipment_id'];
	$no_days_set = $_POST['no_days_set'];
	$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
			$sql="INSERT INTO tbl_schedule (equipment_id,sched_date,no_days_set,remarks,user_id) VALUES (?,?,?,?,?)";
			$qry=$DbConnect->prepare($sql);
			$qry->bind_param("sssss", $equipment_id, $sched_date,$no_days_set,$remarks, $user_id);
			if ($qry->execute())
			{
				 succ();

			}
			else
		{
			error2();
		}
		function succ()
		{
			echo '<script>
			swal({
				title: "Added Schedule Successfully",
				type: "success",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "medicalequipment.php ";
			});
			</script>';
		}
		function error2()
		{
			echo '<script>
			swal({
				title: "Error!!!..",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "medicalequipment.php ";
			});
			</script>';
		}
	
?>