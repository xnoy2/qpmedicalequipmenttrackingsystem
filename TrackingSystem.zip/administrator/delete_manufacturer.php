<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
		<script type="text/javascript" src="dist/sweetalert-dev.js"></script>
	</head>
	

	<body>
		
	</body>

</html>
<?php

require_once 'connect.php';

$manufacturer_id =$_GET['manufacturer_id'];
		$sql1 = "SELECT * FROM tbl_medical_equipment WHERE manufacturer_id=?";
			$qry1 =$DbConnect->prepare($sql1);
			$qry1->bind_param("s",$manufacturer_id);
			$qry1->execute();
			$qry1->store_result();
			$qry1->fetch();
			if ($qry1->num_rows()<=0)
				{
$sql="DELETE FROM tbl_manufacturer WHERE manufacturer_id=?";
$qry=$DbConnect->prepare($sql);
$qry->bind_param("s",$manufacturer_id);
if($qry->execute()==true)
{
	succ();
	
} 
else
{
	err();

}
}
else
{
	err2();
}
function succ()
		{
			echo '<script>
			swal({
				title: "Deleted Successfuly",
				type: "success",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "manufacturer.php ";
			});
			</script>';
		}
		function err()
		{
			echo '<script>
			swal({
				title: "ERROR!!",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "manufacturer.php ";
			});
			</script>';
		}
		function err2()
		{
			echo '<script>
			swal({
				title: "Cant Delete this item. It might already exist in equipment record",
				type: "warning",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "manufacturer.php ";
			});
			</script>';
		}
		?>