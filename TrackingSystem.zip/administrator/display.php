<?php
	// include database connection file

	include "config.php";

	// fetch data from student table..

	$output = "";
	
	$sql = "SELECT * FROM tbl_medical_equipment ORDER BY equipment_id ASC";
	
	$query = mysqli_query($con, $sql);

	if (mysqli_num_rows($query) > 0) {
		$output .= "<table id='example1' class='table table-bordered table-striped'>
		<thead>
			<tr>
					<th></th>
				 	<th>Image</th>
                    <th>Asset Tag</th>
                    <th>Equipment</th>
                    <th>Description</th>
                    <th>Warranty</th>
                    <th>Price</th>
                    <th>Depreciation</th>
			</tr>
		</thead>";
		while ($row = mysqli_fetch_assoc($query)) {
		$output .= "<tbody>
				<tr>
					<td><input type='checkbox' class='delete-id' value='{$row['equipment_id']}'></td>
					<td>{$row['equipment_id']}</td>
					<td>{$row['asset_tag']}</td>
					<td>{$row['equipment_name']}</td>
					<td>{$row['equipment_description']}</td>
					<td>{$row['warranty']}</td>
					<td>{$row['price']}</td>
					<td>{$row['depreciation_value']}</td>
				</tr>
			</tbody>";
		}
		$output .= "
		<tfoot>
			<tr>
					<th></th>
				 	<th>Image</th>
                    <th>Asset Tag</th>
                    <th>Equipment</th>
                    <th>Description</th>
                    <th>Warranty</th>
                    <th>Price</th>
                    <th>Depreciation</th>
			</tr>
		</tfoot>";
	$output .="</table>";
		echo $output;
	}else{
		echo "<h5>No record found</h5>";
	}
	
?>