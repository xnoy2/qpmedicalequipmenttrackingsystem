<?php
include "connect.php";
$calibration_id = $_POST['calibration_id'];
$query="SELECT * from tbl_calibration_report WHERE id = '" . $calibration_id . "'";
$result = mysqli_query($DbConnect,$query);
$cust = mysqli_fetch_array($result);
if($cust) {
echo json_encode($cust);
} 
else 
{
echo "Error: " . $sql . "" . mysqli_error($dbCon);
}
?>