
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
        <script type="text/javascript" src="dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>

</html>
<?php
require_once 'connect.php';
$vendor_id= isset($_POST['vendor_idz'])? $_POST['vendor_idz']:"";
        $sql1 = "SELECT * FROM tbl_medical_equipment WHERE vendor_id=?";
            $qry1 =$DbConnect->prepare($sql1);
            $qry1->bind_param("s",$vendor_id);
            $qry1->execute();
            $qry1->store_result();
            $qry1->fetch();
            if ($qry1->num_rows()<=0)
                {
$vendor_id= isset($_POST['vendor_idz'])? $_POST['vendor_idz']:"";
$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
$vendor_name=$_POST['vendor_name'];

$vendor_address=$_POST['vendor_address'];
$vendor_contact =$_POST['vendor_contact'];
if (!empty($vendor_name) && !empty($vendor_address) && !empty($vendor_contact))
{
    $sql = "UPDATE tbl_vendor SET vendor_name=?, vendor_address=?, vendor_contact=?, user_id=? WHERE vendor_id=?";
    $qry =$DbConnect->prepare($sql);
    $qry->bind_param("sssss",$vendor_name,$vendor_address,$vendor_contact,$user_id,$vendor_id);
    if ($qry->execute())
    {
     succ();    
    }
}
else 
{
    err();
}
}
else
{
    err2();
}
function succ()
        {
            echo '<script>
            swal({
                title: "Updated Successfully",
                type: "success",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "vendor.php ";
            });
            </script>';
        }
        function err()
        {
            echo '<script>
            swal({
                title: "Error!!...",
                type: "error",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "vendor.php ";
            });
            </script>';
        }
       function err2()
        {
            echo '<script>
            swal({
                title: "Cant Update this item. It might already exist in equipment record",
                type: "warning",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "vendor.php ";
            });
            </script>';
        }
?>