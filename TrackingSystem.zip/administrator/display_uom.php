
<?php
  require_once("connect.php");
  $user_id = $_SESSION['user_id'];
  $sql="SELECT tbl_uom.uom_id,tbl_uom.uom_name,tbl_user.user_id,tbl_user.full_name FROM tbl_uom INNER JOIN tbl_user ON tbl_uom.user_id=tbl_user.user_id";
  $qry=$DbConnect->prepare($sql);
  $qry->bind_result($uom_id,$uom_name,$user_id,$full_name);
  $qry->execute();

  while ($qry->fetch())
  {
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_id,full_name FROM tbl_user WHERE user_id=?";
      ?>

      <tr>
      
        <td><b style="color: darkblue"><?php echo $uom_name; ?></b> </td>
        <td><?php echo $full_name; ?> </td>
         <td>
        <button type='button' class='btn btn-info btn-xs' data-toggle='modal' data-target='#update<?php echo $uom_id; ?>'><i class='fa fa-pencil-alt'></i> 
              </button>
          <button type='button' class='btn btn-xs btn-danger ' data-toggle='modal' data-target='#delete<?php echo $uom_id; ?>'><i class="fa fa-trash "></i>  </button>
        </td>
              
      </tr>
      
                  <div class="modal fade" id="update<?php echo $uom_id;?>">
                        <div class="modal-dialog modal-sm">
                            <form action="update_uom.php" method="post" id="form1<?php echo $uom_id; ?>"  name="form1">
                         <input type="hidden" name="uom_idz" value="<?php echo $uom_id; ?>">
                         <input type="hidden" name="user_idz" value="<?php echo $user_id; ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Update UOM</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">UOM</label>
                                  <input type="text" class="form-control" id="" name="uom_name"  value="<?php echo $uom_name; ?>">
                                </div>
                              </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                              <button type="submit" onclick="form1<?php echo $uom_id; ?>.submit();" form="form1" class="btn btn-primary"><i class="fa fa-check"></i> Update</button>
                            </div>
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                      <div class="modal fade" id="delete<?php echo $uom_id;?>" style="margin-left: 30%; margin-top: 20%">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Are you sure you want delete this data?</h5>
              
            </div>
            
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> No!</button>
              <a href="delete_uom.php? uom_id=<?php echo $uom_id; ?>"><button type="button" class="btn btn-primary"><i class="fa fa-check"></i> Yes!</button></a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
         

        
          
<?php 
  }   
  
?>
