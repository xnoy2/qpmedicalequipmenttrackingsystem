  <!DOCTYPE html>
<html>
  <head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
    <script type="text/javascript" src="dist/sweetalert-dev.js"></script>
  </head>
  

  <body>
    
  </body>

</html>

  <?php  
  include ("connect.php");
 $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
      date_default_timezone_set("Asia/Manila");
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $date_of_transfer  = date("Y-m-d");
      $transfer_from= $_POST['transfer_from'];
      $transfer_froms = $_POST['transfer_froms'];
      $remarks = $_POST['remarks'];
      $equipment_id = $_POST['equipment_id'];
      $query = "INSERT INTO tbl_movement_equipment(equipment_id, transfer_from, transfer_froms, date_of_transfer, remarks, user_id) VALUES ('$equipment_id','$transfer_from','$transfer_froms','$date_of_transfer','$remarks','$user_id')";  
 if(mysqli_query($connect, $query))  
      {  
       succ();
     }
    else
      {
     error2();
      }
    function succ()
    {
      echo '<script>
      swal({
        title: "Added Successfully",
        type: "success",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "movementequipment.php ";
      });
      </script>';
    }
    function error2()
    {
      echo '<script>
      swal({
        title: "Error!!!..",
        type: "error",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "movementquipment.php ";
      });
      </script>';
    }  
 ?>  

