 <?php
include 'connect.php';
session_start();

if ($_SESSION['user_id'] ==!empty($user_id))
{
  
  header ('location:../index.php');
}
?>
  <?php
  require_once("connect.php");
  

  $user_id = $_SESSION['user_id'];
  $user_type = $_SESSION['user_type'];
  if ($user_type !== "Administrator")
  {
     header ('location:logoutsession.php');
  }
  else
  {
  $sql= "SELECT user_id,full_name,username,password,user_type,contact,email,avatar FROM tbl_user WHERE user_id=? AND user_type='Administrator' ";
              
  $qry=$DbConnect->prepare($sql);
  $qry->bind_result($user_id,$full_name,$username,$password,$user_type,$contact,$email,$avatar);
  $qry->bind_param("s",$user_id);
  $qry->execute();

  while ($qry->fetch())
  { 
    ?>
  
<?php
}
}
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>QP Medical Equipment Tracking System</title>  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Theme style -->
     <link rel="stylesheet" href="plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
<script type="text/javascript" src="http://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=-7eSns8llm-RMrRDsxHMEIf7RLOedtIl6ZakLhKnAVIi-rbZhzluH4rAXuSX_8wNGEWusUgzMC9IkFMaNASdxErVoYrB2Z8hTL1irKOppalmPhXlsdexC0odXcoEnuLC" charset="UTF-8"></script></head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
 <nav class="main-header navbar navbar-expand navbar-white navbar-light" style="background-color: #28a745;">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars" style="color: #fff;"></i></a>
      </li>
    
    </ul>



    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Messages Dropdown Menu -->
      
      <!-- Notifications Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="modal" data-target="#modal-sm" href="#" style="color: #fff;">
          <i class="fa fa-power-off"></i>

          <span class="badge badge-warning navbar-badge"></span>
        </a>  
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button" style="color: #fff;">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>

    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
       <a href="" class="brand-link">
      <img src="logo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-1" style="
    float: left;
    line-height: .8;
    margin-left: .8rem;
    margin-right: .5rem;
    margin-top: -3px;
    max-height: 33px;
    width: 40px; border-radius: 50%;">
      <span class="brand-text font-weight-light">Tracking System</span>
    </a>


    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <?php echo '<img src="data:image/jpeg;png;jpg;base64,'.base64_encode($avatar).'" class="img-square elevation-3" style="width:30px; border-radius:10%;" alt="User Image" >'; ?>
        </div>
        <div class="info">
         <a href="#" class="d-block" style="margin-top: -7px"><?php echo $full_name; ?></a>
         <a href="#" style="color: #239db1; font-size: 15px"><i class="fa fa-circle text-primary" style="font-size: 13px;"></i > <?php echo $user_type; ?></a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item ">
            <a href="dashboard.php" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
           <li class="nav-item">
            <a href="medicalequipment.php" class="nav-link" style="background-color: #28a745; color: #fff;">
              <i class="nav-icon fas fa-first-aid"></i>
              <p>
                Medical Equipment
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="movementequipment.php" class="nav-link">
              <i class="nav-icon fas fa-tools"></i>
              <p>
                Movement Equipment
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="imageupload.php" class="nav-link">
              <i class="nav-icon fas fa-image"></i>
              <p>
                Image Upload
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="calibrationreport.php" class="nav-link" >
              <i class="nav-icon fas fa-chart-bar"></i>
              <p>
                Calibration Report
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="depreciation_report.php" class="nav-link">
              <i class="nav-icon fas fa-edit"></i>
              <p>
                Depreciation Report
              </p>
            </a>
          </li>
           <li class="nav-header" style="margin-top: -8%; margin-left: 20%; color: #17a2b8; font-weight: 10%;">Management</li>
              <li class="nav-item">
                <a href="brand.php" class="nav-link">
              <i class="nav-icon fas fa-tag"></i>
                  <p>Brand</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="category.php" class="nav-link">
              <i class="nav-icon fas fa-th-large"></i>
                  <p>Category</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="assettype.php" class="nav-link">
              <i class="nav-icon fas fa-hand-holding-usd"></i>
                  <p>Asset Type</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="vendor.php" class="nav-link">
              <i class="nav-icon fas fa-house-user"></i>
                  <p>Vendor Information</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="clinic.php" class="nav-link">
              <i class="nav-icon fas fa-clinic-medical"></i>
                  <p>Clinic Information</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="clinicsection.php" class="nav-link">
              <i class="nav-icon fas fa-clinic-medical"></i>
                  <p>Clinic Section</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="subclinicsection.php" class="nav-link">
              <i class="nav-icon fas fa-clinic-medical"></i>
                  <p>Clinic Sub Section</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="region.php" class="nav-link">
              <i class="nav-icon fas fa-church"></i>
                  <p>Region</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="status.php" class="nav-link">
              <i class="nav-icon fas fa-edit"></i>
                  <p>Item Condition</p>
                </a>
              </li>
              
              <li class="nav-item">
                <a href="uom.php" class="nav-link">
              <i class="nav-icon fas fa-balance-scale-left"></i>
                  <p>UOM</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="manufacturer.php" class="nav-link">
              <i class="nav-icon fas fa-industry"></i>
                  <p>Manufacturer</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="user.php" class="nav-link">
              <i class="nav-icon fas fa-user"></i>
                  <p>User</p>
                </a>
              </li>
         
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Medical Equipment</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Medical Equipment</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
          <div class="modal fade" id="modal-sm" style="margin-left: 30%">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Are you sure you want to log out?</h5>
              
            </div>
            
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> No!</button>
              <a href="logoutsession.php"><button type="button" class="btn btn-primary"><i class="fa fa-check"></i> Yes!</button></a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
       

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Medical Equipment Data table</h3> 
                <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#maintenance" style="margin-left:45%"><i class="fa fa-tools"></i>
                </button> 
                <a href="medicalequipment_rejected.php"  >
                  <button type="button" class="btn btn-info btn-sm" ><i class="fa fa-arrow-left"> Rejected Items</i>
                </button>
              </a>
               <a href="medicalequipment_pending.php"  >
                  <button type="button" class="btn btn-primary btn-sm" ><i class="fa fa-arrow-right"> Pending Items</i>
                </button>
              </a>
                <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#add" ><i class="fa fa-plus">Add</i>
                </button>
                <div class="modal fade" id="add">
                        <div class="modal-dialog modal-lg">
                            <form action="add_medicalequipment.php" method="post" enctype="multipart/form-data">
                             <input type="hidden" name="user_idz" value="<?php echo $user_id; ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Add Medical Equipment</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="row">
                                  <div class="col-3">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Asset Tag</label>
                                  <input type="text" class="form-control" id="" name="asset_tag" required="" placeholder="Enter Asset Tag..">
                                </div>
                              </div>
                                <div class="col-4">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Equipment</label>
                                  <input type="text" class="form-control" id="" name="equipment_name"  required="" placeholder="Enter Equipment Name..">
                                </div>
                              </div>
                                <div class="col-5">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Description</label>
                                  <textarea class="form-control" rows="2" name="equipment_description" required="" placeholder="Enter ..."></textarea>
                                </div>
                              </div>
                               
                              <div class="col-2">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Qty</label>
                                  <input type="number" class="form-control" id="" required="" name="quantity_on_hand" placeholder="0">
                                </div>
                              </div>
                              <div class="col-4">
                                  <div class="form-group">
                                  <label>Warranty</label>
                                  <select class="form-control" name="warranty">
                                    <option>5 Years</option>
                                    <option>10 Years</option>
                                      <option>No Warranty</option>
                                    <option>Under Preventive Maintenance</option>
                                  </select>
                                </div>
                              </div>
                              <div class="col-3">
                                  <div class="form-group">
                                  <label>UOM</label>
                                  <select class="form-control select2" name="uom_id">
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_uom.uom_id,tbl_uom.uom_name FROM tbl_uom ORDER BY tbl_uom.uom_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($uom_id,$uom_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $uom_id ?>"><?php echo $uom_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-3">
                                  <div class="form-group">
                                  <label>Brand</label>
                                  <select class="form-control select2" name="brand_id">
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_brand.brand_id,tbl_brand.brand_name FROM tbl_brand ORDER BY tbl_brand.brand_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($brand_id,$brand_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $brand_id ?>"><?php echo $brand_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-4">
                                  <div class="form-group">
                                  <label>Category</label>
                                  <select class="form-control select2" style="width: 100%;" name="category_id">
                                     <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_category.category_id,tbl_category.category_name FROM tbl_category ORDER BY tbl_category.category_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($category_id,$category_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $category_id ?>"><?php echo $category_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                 </select>
                                </div>
                              </div>
                                <div class="col-4">
                                  <div class="form-group">
                                  <label>Asset Type</label>
                                    <select class="form-control select2" style="width: 100%;" name="asset_type_id">
                                     <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_asset_type.asset_type_id,tbl_asset_type.type_name FROM tbl_asset_type ORDER BY tbl_asset_type.type_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($asset_type_id,$type_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $asset_type_id ?>"><?php echo $type_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                 </select>
                                </div>
                              </div>
                               <div class="col-4">
                                  <div class="form-group">
                                  <label>Region</label>
                                  <select class="form-control select2" name="region_id">
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_region.region_id,tbl_region.region_name FROM tbl_region ORDER BY tbl_region.region_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($region_id,$region_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $region_id ?>"><?php echo $region_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-4">
                                  <div class="form-group">
                                  <label>Clinic</label>
                                  <select class="form-control select2" name="clinic_id">
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_clinic.clinic_id,tbl_clinic.clinic_name FROM tbl_clinic ORDER BY tbl_clinic.clinic_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($clinic_id,$clinic_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $clinic_id ?>"><?php echo $clinic_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-4">
                                  <div class="form-group">
                                  <label>Clinic Section</label>
                                  <select class="form-control select2" name="clinic_section_id">
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_section.clinic_section_id,tbl_section.section_name FROM tbl_section ORDER BY tbl_section.section_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($clinic_section_id,$section_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $clinic_section_id ?>"><?php echo $section_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-4">
                                  <div class="form-group">
                                  <label>Clinic Sub Section</label>
                                  <select class="form-control select2" name="sub_section_id">
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_sub_section.sub_section_id,tbl_sub_section.sub_section_name FROM tbl_sub_section ORDER BY tbl_sub_section.sub_section_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($sub_section_id,$sub_section_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $sub_section_id ?>"><?php echo $sub_section_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                             
                              <div class="col-4">
                                  <div class="form-group">
                                  <label>Manufacturer</label>
                                  <select class="form-control select2" name="manufacturer_id">
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_manufacturer.manufacturer_id,tbl_manufacturer.manufacturer_name FROM tbl_manufacturer ORDER BY tbl_manufacturer.manufacturer_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($manufacturer_id,$manufacturer_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $manufacturer_id ?>"><?php echo $manufacturer_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-4">
                                  <div class="form-group">
                                  <label>Vendor</label>
                                  <select class="form-control select2" name="vendor_id">
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_vendor.vendor_id,tbl_vendor.vendor_name FROM tbl_vendor ORDER BY tbl_vendor.vendor_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($vendor_id,$vendor_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $vendor_id ?>"><?php echo $vendor_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                             
                              <div class="col-4">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">PO Number</label>
                                  <input type="text" class="form-control" id="" name="po_number" required="" placeholder="Enter PO Number..">
                                </div>
                              </div>
                              <div class="col-4">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Serial Number</label>
                                  <input type="text" class="form-control" id="" name="serial_number" required="" placeholder="Enter Serial Number..">
                                </div>
                              </div>
                              <div class="col-3">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Model Number</label>
                                  <input type="text" class="form-control" id="" name="model_number" required="" placeholder="Enter Model Number..">
                                </div>
                              </div>
                             <div class="col-2">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Price</label>
                                  <input type="number" class="form-control" id="" name="price" required="" placeholder="00.00">
                                </div>
                              </div>
                              <div class="col-3">
                                  <div class="form-group">
                                  <label>Item Condition</label>
                                  <select class="form-control select2" name="status_id">
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_status.status_id,tbl_status.status_name FROM tbl_status GROUP BY tbl_status.status_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($status_id,$status_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $status_id ?>"><?php echo $status_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-3">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Primary Image</label>
                                  <input type="file" name="primary_image" id="primary_image" required="">
                                </div>
                              </div>

                              
                              </div>
                            </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                             <input type="submit" name="primary_image" id="primary_image" value="Submit" class="btn btn-primary" />
                           </div>
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                       <div class="modal fade" id="maintenance">
                        <div class="modal-dialog modal-sm">
                            <form action="addsched.php" method="post" >
                            <input type="hidden" name="user_idz" value="<?php echo $user_id; ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Schedule Maintenance</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Equipment</label>
                                  <select class="form-control" name="equipment_id">
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_medical_equipment.equipment_id,tbl_medical_equipment.equipment_name FROM tbl_medical_equipment";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($equipment_id,$equipment_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $equipment_id ?>"><?php echo $equipment_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                                    <div class="form-group">
                                  <label for="exampleInputEmail1">Date</label>
                                  <input type="date" name="sched_date"  class="form-control" id="" required=""  placeholder="Enter Brand Name..">
                                </div>
                                <div class="form-group">
                                  <label for="exampleInputEmail1">No of days</label>
                                  <input type="number" class="form-control" id="" name="no_days_set" required="" placeholder="0">
                                </div>
                                <div class="form-group">
                                  <label for="exampleInputPassword1">Remarks</label>
                                  <textarea class="form-control"  name="remarks" rows="4" required="" placeholder="Enter ..."></textarea>
                                </div>
                              </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                              <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Submit</button>
                            </div>  
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">

                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Asset Tag</th>
                    <th>Equipment</th>
                    <th>Description</th>
                    <th>Primary Image</th>
                    <th>Quantity</th>
                    <th>Warranty<sup>5or10yrs</sup></th>
                    <th>Price</th>
                    <th>Depreciation Value</th>
                    <th>UOM</th>
                    <th>Brand</th>
                    <th>Category</th>
                    <th>Asset Type</th>
                    <th>Clinic Information</th>
                    <th>Clinic Section</th>
                    <th>Sub Section</th>
                    <th>Region</th>
                    <th>Manufacturer</th>
                    <th>Vendor</th>
                    <th>Item Condition</th>
                    <th>PO #</th>
                    <th>Serial #</th>
                    <th>Model #</th>
                    <th>Date Acquired</th>
                    <th>Manage By</th>
                    <th width="10%"></th>
                  </tr>
                  </thead>
                  <tbody>
                <?php include 'display_equipment.php'; ?>
                  </tbody>
                  <tfoot>
                  <tr>
                    <th>Asset Tag</th>
                    <th>Equipment</th>
                    <th>Description</th>
                    <th>Primary Image</th>
                    <th>Quantity</th>
                    <th>Warranty<sup>5or10yrs</sup></th>
                    <th>Price</th>
                    <th>Depreciation Value</th>
                    <th>UOM</th>
                    <th>Brand</th>
                    <th>Category</th>
                    <th>Asset Type</th>
                    <th>Clinic Information</th>
                    <th>Clinic Section</th>
                    <th>Sub Section</th>
                    <th>Region</th>
                    <th>Manufacturer</th>
                    <th>Vendor</th>
                     <th>Item Condition</th>
                    <th>PO #</th>
                    <th>Serial #</th>
                    <th>Model #</th>
                    <th>Date Acquired</th>
                    <th>Manage By</th>
                    <th width="7%"></th>
                  </tr>
                  </tfoot>
                </table>
                
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Footer <a href="" style="color: #3d9970">Medical Equipment Tracking System</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Footer</b>
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
    <script src="dropdownajax.js"></script>
    <script>
$('#countries-list').on('change', function(){
    var category_id = this.value;
    $.ajax({
  type: "POST",
  url: "meddrop.php",
  data:'category_id='+category_id,
  success: function(result){
    $("#states-list").html(result);
  }
  });
});
</script>

<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="plugins/jszip/jszip.min.js"></script>
<script src="plugins/pdfmake/pdfmake.min.js"></script>
<script src="plugins/pdfmake/vfs_fonts.js"></script>
<script src="plugins/select2/js/select2.full.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>

<!-- Page specific script -->
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": [""]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservationdate').datetimepicker({
        format: 'L'
    });
    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({
      timePicker: true,
      timePickerIncrement: 30,
      locale: {
        format: 'MM/DD/YYYY hh:mm A'
      }
    })
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //Timepicker
    $('#timepicker').datetimepicker({
      format: 'LT'
    })

    //Bootstrap Duallistbox
    $('.duallistbox').bootstrapDualListbox()

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    $('.my-colorpicker2').on('colorpickerChange', function(event) {
      $('.my-colorpicker2 .fa-square').css('color', event.color.toString());
    });

    $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch('state', $(this).prop('checked'));
    });

  })
  // BS-Stepper Init
  document.addEventListener('DOMContentLoaded', function () {
    window.stepper = new Stepper(document.querySelector('.bs-stepper'))
  });

  // DropzoneJS Demo Code Start
  Dropzone.autoDiscover = false;

  // Get the template HTML and remove it from the doumenthe template HTML and remove it from the doument
  var previewNode = document.querySelector("#template");
  previewNode.id = "";
  var previewTemplate = previewNode.parentNode.innerHTML;
  previewNode.parentNode.removeChild(previewNode);

  var myDropzone = new Dropzone(document.body, { // Make the whole body a dropzone
    url: "/target-url", // Set the url
    thumbnailWidth: 80,
    thumbnailHeight: 80,
    parallelUploads: 20,
    previewTemplate: previewTemplate,
    autoQueue: false, // Make sure the files aren't queued until manually added
    previewsContainer: "#previews", // Define the container to display the previews
    clickable: ".fileinput-button" // Define the element that should be used as click trigger to select files.
  });

  myDropzone.on("addedfile", function(file) {
    // Hookup the start button
    file.previewElement.querySelector(".start").onclick = function() { myDropzone.enqueueFile(file); };
  });

  // Update the total progress bar
  myDropzone.on("totaluploadprogress", function(progress) {
    document.querySelector("#total-progress .progress-bar").style.width = progress + "%";
  });

  myDropzone.on("sending", function(file) {
    // Show the total progress bar when upload starts
    document.querySelector("#total-progress").style.opacity = "1";
    // And disable the start button
    file.previewElement.querySelector(".start").setAttribute("disabled", "disabled");
  });

  // Hide the total progress bar when nothing's uploading anymore
  myDropzone.on("queuecomplete", function(progress) {
    document.querySelector("#total-progress").style.opacity = "0";
  });

  // Setup the buttons for all transfers
  // The "add files" button doesn't need to be setup because the config
  // `clickable` has already been specified.
  document.querySelector("#actions .start").onclick = function() {
    myDropzone.enqueueFiles(myDropzone.getFilesWithStatus(Dropzone.ADDED));
  };
  document.querySelector("#actions .cancel").onclick = function() {
    myDropzone.removeAllFiles(true);
  };
  // DropzoneJS Demo Code End
</script>
</body>
</html>
