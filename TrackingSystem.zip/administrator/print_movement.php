<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.4 -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
<script type="text/javascript" src="http://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=-7eSns8llm-RMrRDsxHMEIf7RLOedtIl6ZakLhKnAVIi-rbZhzluH4rAXuSX_8wNGEWusUgzMC9IkFMaNASdxErVoYrB2Z8hTL1irKOppalmPhXlsdexC0odXcoEnuLC" charset="UTF-8"></script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body onload="window.print();">
    <div class="wrapper">
      <!-- Main content -->
      <section class="invoice">
        <!-- title row -->
               <div class="row">
          <div class="col-xs-12" style="margin-left: 22%">
             <img src="print.png" alt="AdminLTE Logo" class="brand-image" width="200" height="200" style="opacity: .8; margin-left:-34%; margin-bottom:-34%"> <h1 class="page-header" >
    QP Medical Equipment Tracking System   
            </h1>
           
          </div><!-- /.col -->
        </div>
        <br>
      <br>
      <br>
        <!-- info row -->


        <!-- Table row -->            <center><h1>Movement Equipment Report</h1></center><small style="margin-left:90%"><?php
    date_default_timezone_set('Asia/Manila');
    echo " ". date('F j, Y');
?></small>
        <div class="row">
          <div class="col-xs-12 table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Equipment</th>
                  <th>Transfer From</th>
                  <th>Transfer To</th>
                  <th>Date Transfer</th>
                  <th>Remarks</th>
                  <th>Manage By</th>
                </tr>
              </thead>
              <tbody>
<?php
  require_once("connect.php");
  date_default_timezone_set("Asia/Manila");
  $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");  
  $sql="SELECT tbl_movement_equipment.movement_id, tbl_movement_equipment.equipment_id, tbl_medical_equipment.equipment_name, tbl_movement_equipment.transfer_from, tbl_movement_equipment.transfer_froms, tbl_movement_equipment.date_of_transfer, tbl_movement_equipment.remarks, tbl_user.user_id, tbl_user.full_name FROM tbl_movement_equipment INNER JOIN tbl_medical_equipment ON tbl_movement_equipment.equipment_id = tbl_medical_equipment.equipment_id INNER JOIN tbl_user ON tbl_movement_equipment.user_id = tbl_user.user_id GROUP BY tbl_movement_equipment.movement_id, tbl_movement_equipment.equipment_id, tbl_medical_equipment.equipment_name, tbl_movement_equipment.transfer_from, tbl_movement_equipment.transfer_froms, tbl_movement_equipment.date_of_transfer, tbl_movement_equipment.remarks, tbl_user.user_id, tbl_user.full_name";
  $qry=$DbConnect->prepare($sql);
  $qry->bind_result($movement_id,$equipment_id,$equipment_name,$transfer_from,$transfer_froms,$date_of_transfer,$remarks,$user_id,$full_name);
$qry->execute();
$result = mysqli_query($connect, $sql);  
while($row = mysqli_fetch_array($result))
  { 
    ?>

      <tr>
      
        <td><b style="color: blue;"><?php printf ("%s", $row["equipment_name"]); ?> </b></td>
        <td><?php printf ("%s", $row["transfer_from"]); ?> </td>
        <td><?php printf ("%s", $row["transfer_froms"]); ?> </td>
        <td><?php $date_of_transfer=strtotime($row['date_of_transfer']);
          echo date("M-d-Y",$date_of_transfer)?></td>
        <td><?php printf ("%s", $row["remarks"]); ?></td>
        <td><?php printf ("%s", $row["full_name"]); ?> </td>
         <td>

      
                
          
<?php 
  }   
  
?>

              </tbody>
            </table>
<br><br>
          </div><!-- /.col -->
          <h4 style="margin-left:2%"> Submitted By :</h4>
          <h4 style="margin-left:1%"><b><?php
          $full_name = $_GET['full_name'];
          echo $full_name;
          ?></b></h4>
        </div><!-- /.row -->
      </section><!-- /.content -->
    </div><!-- ./wrapper -->

    <!-- AdminLTE App -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<!-- Sparkline -->
<script src="plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<!-- jQuery Knob Chart -->
<script src="plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="plugins/moment/moment.min.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard.js"></script>
  </body>
</html>
