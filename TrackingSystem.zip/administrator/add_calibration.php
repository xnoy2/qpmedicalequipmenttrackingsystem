  <!DOCTYPE html>
<html>
  <head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
    <script type="text/javascript" src="dist/sweetalert-dev.js"></script>
  </head>
  

  <body>
    
  </body>

</html>

   
  <?php  
  include 'connect.php';
 $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
date_default_timezone_set("Asia/Manila");
if (isset($_POST["submit"]))
{      
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $uploaded_date  = date("Y-m-d");  
      $equipment_id = $_POST["equipment_id"];
      $report_name = $_POST["report_name"];
      $report_description = $_POST["report_description"];
      $equipment_id = $_POST["equipment_id"];
      $status = 'Approved';
     
   $pname = rand(1000,10000)."-".$_FILES["file_uploaded"]["name"];
 
    #temporary file name to store file
    $tname = $_FILES["file_uploaded"]["tmp_name"];

   $uploads_dir = 'Uploaded';
    #TO move the uploaded file to specific location
    move_uploaded_file($tname, $uploads_dir.'/'.$pname);
 
    #sql query to insert into database
    $sql = "INSERT INTO tbl_calibration_report (equipment_id,report_name,report_description,file_uploaded,uploaded_date,status,user_id) VALUES('$equipment_id','$report_name','$report_description','$pname','$uploaded_date', '$status', '$user_id')";
 
    if(mysqli_query($connect,$sql)){
 
    succ();
    }
    else{
        error2();
    }
  }
  function succ()
    {
      echo '<script>
      swal({
        title: "Added Successfully",
        type: "success",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "calibrationreport.php ";
      });
      </script>';
    }
    function error2()
    {
      echo '<script>
      swal({
        title: "Error!!!..",
        type: "error",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "calibrationreport.php ";
      });
      </script>';
    }  
 ?>  
