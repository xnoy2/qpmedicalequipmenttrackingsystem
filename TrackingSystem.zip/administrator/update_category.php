
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
        <script type="text/javascript" src="dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>

</html>
<?php
require_once 'connect.php';
$category_id= isset($_POST['category_idz'])? $_POST['category_idz']:"";
$sql1 = "SELECT * FROM tbl_medical_equipment WHERE category_id=?";
            $qry1 =$DbConnect->prepare($sql1);
            $qry1->bind_param("s",$category_id);
            $qry1->execute();
            $qry1->store_result();
            $qry1->fetch();
            if ($qry1->num_rows()<=0)
                {
$category_id= isset($_POST['category_idz'])? $_POST['category_idz']:"";
$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
$category_name=$_POST['category_name'];
$category_description=$_POST['category_description'];
if (!empty($category_name))
{
    $sql = "UPDATE tbl_category SET category_name=?, category_description=?, user_id=? WHERE category_id=?";
    $qry =$DbConnect->prepare($sql);
    $qry->bind_param("ssss",$category_name,$category_description,$user_id,$category_id);
    if ($qry->execute())
    {
     succ();    
    }
}
else 
{
    err();
}
}
else
{
    err2();
}
function succ()
        {
            echo '<script>
            swal({
                title: "Updated Successfully",
                type: "success",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "category.php ";
            });
            </script>';
        }
        function err()
        {
            echo '<script>
            swal({
                title: "Error!!...",
                type: "error",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "category.php ";
            });
            </script>';
        }
        function err2()
        {
            echo '<script>
            swal({
                title: "Cant Update this item. It might already exist in equipment record",
                type: "warning",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "category.php ";
            });
            </script>';
        }
?>