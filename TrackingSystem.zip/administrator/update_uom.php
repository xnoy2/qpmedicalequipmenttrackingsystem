
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
        <script type="text/javascript" src="dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>

</html>
<?php
require_once 'connect.php';
$uom_id= isset($_POST['uom_idz'])? $_POST['uom_idz']:"";
$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
        $sql1 = "SELECT * FROM tbl_medical_equipment WHERE uom_id=?";
            $qry1 =$DbConnect->prepare($sql1);
            $qry1->bind_param("s",$uom_id);
            $qry1->execute();
            $qry1->store_result();
            $qry1->fetch();
            if ($qry1->num_rows()<=0)
                {
$uom_name=$_POST['uom_name'];
if (!empty($uom_name))
{
    $sql = "UPDATE tbl_uom SET uom_name=?, user_id=? WHERE uom_id=?";
    $qry =$DbConnect->prepare($sql);
    $qry->bind_param("sss",$uom_name,$user_id,$uom_id);
    if ($qry->execute())
    {
     succ();    
    }
}
else 
{
    err();
}
}
else
{
    err2();
}
function succ()
        {
            echo '<script>
            swal({
                title: "Updated Successfully",
                type: "success",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "uom.php ";
            });
            </script>';
        }
        function err()
        {
            echo '<script>
            swal({
                title: "Error!!...",
                type: "error",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "uom.php ";
            });
            </script>';
        }
        function err2()
        {
            echo '<script>
            swal({
                title: "Cant Update this item. It might already exist in equipment record",
                type: "warning",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "uom.php ";
            });
            </script>';
        }
        ?>