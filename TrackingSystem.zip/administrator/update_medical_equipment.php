
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
        <script type="text/javascript" src="dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body> 
</html>
<?php
include 'connect.php';
 $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
       $warranty = $_POST['warranty'];
      if ($warranty == '10 Years' && $_FILES['primary_image']['name'] == "")
      {
      $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
      date_default_timezone_set("Asia/Manila");
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $equipment_id= isset($_POST['equipment_idz'])? $_POST['equipment_idz']:"";
      $asset_tag = $_POST['asset_tag'];
      $equipment_name = $_POST['equipment_name'];  
      $equipment_description = $_POST['equipment_description'];  
      $quantity_on_hand = $_POST['quantity_on_hand'];  
      $price = $_POST['price'];  
      $warranty = $_POST['warranty'];
      $uom_id = $_POST['uom_id'];
      $brand_id = $_POST['brand_id'];
      $category_id = $_POST['category_id'];
      $clinic_id = $_POST['clinic_id'];
      $clinic_section_id = $_POST['clinic_section_id'];
      $sub_section_id = $_POST['sub_section_id'];
      $region_id = $_POST['region_id'];
      $manufacturer_id = $_POST['manufacturer_id'];
      $vendor_id = $_POST['vendor_id'];
      $po_number = $_POST['po_number'];
      $serial_number = $_POST['serial_number'];
      $model_number = $_POST['model_number'];
      $status_id = $_POST['status_id'];
      $status = $_POST['status'];
      $asset_type_id = $_POST['asset_type_id'];
      $date_acquired  = date("Y-m-d");
      $depreciation_value = $price * 0.1;
      $query = ("UPDATE tbl_medical_equipment SET asset_tag='".$asset_tag."', equipment_name='".$equipment_name."', equipment_description='".$equipment_description."', quantity_on_hand='".$quantity_on_hand."', price='".$price."', warranty='".$warranty."', depreciation_value='".$depreciation_value."',  asset_type_id='".$asset_type_id."', uom_id='".$uom_id."',  brand_id='".$brand_id."', category_id='".$category_id."',  clinic_id='".$clinic_id."', clinic_section_id='".$clinic_section_id."',  sub_section_id='".$sub_section_id."', region_id='".$region_id."',  manufacturer_id='".$manufacturer_id."', vendor_id='".$vendor_id."', po_number='".$po_number."', serial_number='".$serial_number."', model_number='".$model_number."', date_acquired='".$date_acquired."', status_id='".$status_id."', user_id='".$user_id."',  status='".$status."' WHERE equipment_id = '".$equipment_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
        error2();
      }
      }
      else if ($warranty == '5 Years' && $_FILES['primary_image']['name'] == "")
      {
      include 'connect.php';
      $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
      date_default_timezone_set("Asia/Manila");
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $equipment_id= isset($_POST['equipment_idz'])? $_POST['equipment_idz']:"";
      $asset_tag = $_POST['asset_tag'];
      $equipment_name = $_POST['equipment_name'];  
      $equipment_description = $_POST['equipment_description'];  
      $quantity_on_hand = $_POST['quantity_on_hand'];  
      $price = $_POST['price'];  
      $warranty = $_POST['warranty'];
      $uom_id = $_POST['uom_id'];
      $brand_id = $_POST['brand_id'];
      $category_id = $_POST['category_id'];
      $clinic_id = $_POST['clinic_id'];
      $clinic_section_id = $_POST['clinic_section_id'];
      $sub_section_id = $_POST['sub_section_id'];
      $region_id = $_POST['region_id'];
      $manufacturer_id = $_POST['manufacturer_id'];
      $vendor_id = $_POST['vendor_id'];
      $po_number = $_POST['po_number'];
      $serial_number = $_POST['serial_number'];
      $model_number = $_POST['model_number'];
      $status_id = $_POST['status_id'];
      $status = $_POST['status'];
      $asset_type_id = $_POST['asset_type_id'];
      $date_acquired  = date("Y-m-d");
      $depreciation_value = $price * 0.005;
      $query = ("UPDATE tbl_medical_equipment SET asset_tag='".$asset_tag."', equipment_name='".$equipment_name."', equipment_description='".$equipment_description."', quantity_on_hand='".$quantity_on_hand."', price='".$price."', warranty='".$warranty."', depreciation_value='".$depreciation_value."',  asset_type_id='".$asset_type_id."', uom_id='".$uom_id."',  brand_id='".$brand_id."', category_id='".$category_id."',  clinic_id='".$clinic_id."', clinic_section_id='".$clinic_section_id."',  sub_section_id='".$sub_section_id."', region_id='".$region_id."',  manufacturer_id='".$manufacturer_id."', vendor_id='".$vendor_id."', po_number='".$po_number."', serial_number='".$serial_number."', model_number='".$model_number."', date_acquired='".$date_acquired."', status_id='".$status_id."', user_id='".$user_id."',  status='".$status."'  WHERE equipment_id = '".$equipment_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ(); 
      }
      else
      {
        error2();
      }
      }
      else if ($_FILES['primary_image']['name'] !==""  && $warranty == '10 Years')
      {
      $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
     
      date_default_timezone_set("Asia/Manila");
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $equipment_id= isset($_POST['equipment_idz'])? $_POST['equipment_idz']:"";
      $asset_tag = $_POST['asset_tag'];
      $equipment_name = $_POST['equipment_name'];  
      $equipment_description = $_POST['equipment_description'];  
      $quantity_on_hand = $_POST['quantity_on_hand'];  
      $price = $_POST['price'];  
      $warranty = $_POST['warranty'];
      $uom_id = $_POST['uom_id'];
      $brand_id = $_POST['brand_id'];
      $category_id = $_POST['category_id'];
      $clinic_id = $_POST['clinic_id'];
      $clinic_section_id = $_POST['clinic_section_id'];
      $sub_section_id = $_POST['sub_section_id'];
      $region_id = $_POST['region_id'];
      $manufacturer_id = $_POST['manufacturer_id'];
      $vendor_id = $_POST['vendor_id'];
      $po_number = $_POST['po_number'];
      $serial_number = $_POST['serial_number'];
      $model_number = $_POST['model_number'];
      $status_id = $_POST['status_id'];
      $status = $_POST['status'];
      $asset_type_id = $_POST['asset_type_id'];
      $date_acquired  = date("Y-m-d");
       $depreciation_value = $price * 0.1;
      $primary_image = addslashes(file_get_contents($_FILES["primary_image"]["tmp_name"]));
      $query = ("UPDATE tbl_medical_equipment SET asset_tag='".$asset_tag."', equipment_name='".$equipment_name."',  primary_image='".$primary_image."', equipment_description='".$equipment_description."', quantity_on_hand='".$quantity_on_hand."', price='".$price."', warranty='".$warranty."', depreciation_value='".$depreciation_value."',  asset_type_id='".$asset_type_id."', uom_id='".$uom_id."',  brand_id='".$brand_id."', category_id='".$category_id."',  clinic_id='".$clinic_id."', clinic_section_id='".$clinic_section_id."',  sub_section_id='".$sub_section_id."', region_id='".$region_id."',  manufacturer_id='".$manufacturer_id."', vendor_id='".$vendor_id."', po_number='".$po_number."', serial_number='".$serial_number."', model_number='".$model_number."', date_acquired='".$date_acquired."', status_id='".$status_id."', user_id='".$user_id."',  status='".$status."'  WHERE equipment_id = '".$equipment_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
        error2();
      }
      }
      else if ($_FILES['primary_image']['name'] !== "" && $warranty == '5 Years')
      {
      $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
      date_default_timezone_set("Asia/Manila");
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $equipment_id= isset($_POST['equipment_idz'])? $_POST['equipment_idz']:"";
      $asset_tag = $_POST['asset_tag'];
      $equipment_name = $_POST['equipment_name'];  
      $equipment_description = $_POST['equipment_description'];  
      $quantity_on_hand = $_POST['quantity_on_hand'];  
      $price = $_POST['price'];  
      $warranty = $_POST['warranty'];
      $uom_id = $_POST['uom_id'];
      $brand_id = $_POST['brand_id'];
      $category_id = $_POST['category_id'];
      $clinic_id = $_POST['clinic_id'];
      $clinic_section_id = $_POST['clinic_section_id'];
      $sub_section_id = $_POST['sub_section_id'];
      $region_id = $_POST['region_id'];
      $manufacturer_id = $_POST['manufacturer_id'];
      $vendor_id = $_POST['vendor_id'];
      $po_number = $_POST['po_number'];
      $serial_number = $_POST['serial_number'];
      $model_number = $_POST['model_number'];
      $status_id = $_POST['status_id'];
      $status = $_POST['status'];
      $asset_type_id = $_POST['asset_type_id'];
      $date_acquired  = date("Y-m-d");
      $depreciation_value = $price * 0.005;
      $primary_image = addslashes(file_get_contents($_FILES["primary_image"]["tmp_name"]));
      $query = ("UPDATE tbl_medical_equipment SET asset_tag='".$asset_tag."', equipment_name='".$equipment_name."',  primary_image='".$primary_image."', equipment_description='".$equipment_description."', quantity_on_hand='".$quantity_on_hand."', price='".$price."', warranty='".$warranty."', depreciation_value='".$depreciation_value."',  asset_type_id='".$asset_type_id."', uom_id='".$uom_id."',  brand_id='".$brand_id."', category_id='".$category_id."',  clinic_id='".$clinic_id."', clinic_section_id='".$clinic_section_id."',  sub_section_id='".$sub_section_id."', region_id='".$region_id."',  manufacturer_id='".$manufacturer_id."', vendor_id='".$vendor_id."', po_number='".$po_number."', serial_number='".$serial_number."', model_number='".$model_number."', date_acquired='".$date_acquired."', status_id='".$status_id."', user_id='".$user_id."', status='".$status."'  WHERE equipment_id = '".$equipment_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
        error2();
      }
      }
      else  if ($_FILES['primary_image']['name'] !== "" && $warranty == 'No Warranty')
      {
      $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
      date_default_timezone_set("Asia/Manila");
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $equipment_id= isset($_POST['equipment_idz'])? $_POST['equipment_idz']:"";
      $asset_tag = $_POST['asset_tag'];
      $equipment_name = $_POST['equipment_name'];  
      $equipment_description = $_POST['equipment_description'];  
      $quantity_on_hand = $_POST['quantity_on_hand'];  
      $price = $_POST['price'];  
      $warranty = $_POST['warranty'];
      $uom_id = $_POST['uom_id'];
      $brand_id = $_POST['brand_id'];
      $category_id = $_POST['category_id'];
      $clinic_id = $_POST['clinic_id'];
      $clinic_section_id = $_POST['clinic_section_id'];
      $sub_section_id = $_POST['sub_section_id'];
      $region_id = $_POST['region_id'];
      $manufacturer_id = $_POST['manufacturer_id'];
      $vendor_id = $_POST['vendor_id'];
      $po_number = $_POST['po_number'];
      $serial_number = $_POST['serial_number'];
      $model_number = $_POST['model_number'];
      $status_id = $_POST['status_id'];
      $status = $_POST['status'];
      $asset_type_id = $_POST['asset_type_id'];
      $date_acquired  = date("Y-m-d");
      $depreciation_value = $price;
      $primary_image = addslashes(file_get_contents($_FILES["primary_image"]["tmp_name"]));
      $query = ("UPDATE tbl_medical_equipment SET asset_tag='".$asset_tag."', equipment_name='".$equipment_name."',  primary_image='".$primary_image."', equipment_description='".$equipment_description."', quantity_on_hand='".$quantity_on_hand."', price='".$price."', warranty='".$warranty."', depreciation_value='".$depreciation_value."',  asset_type_id='".$asset_type_id."', uom_id='".$uom_id."',  brand_id='".$brand_id."', category_id='".$category_id."',  clinic_id='".$clinic_id."', clinic_section_id='".$clinic_section_id."',  sub_section_id='".$sub_section_id."', region_id='".$region_id."',  manufacturer_id='".$manufacturer_id."', vendor_id='".$vendor_id."', po_number='".$po_number."', serial_number='".$serial_number."', model_number='".$model_number."', date_acquired='".$date_acquired."', status_id='".$status_id."', user_id='".$user_id."',  status='".$status."'  WHERE equipment_id = '".$equipment_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
        error2();
      }
      }
            else  if ($_FILES['primary_image']['name'] == "" && $warranty == 'No Warranty')
      {
      $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
      date_default_timezone_set("Asia/Manila");
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $equipment_id= isset($_POST['equipment_idz'])? $_POST['equipment_idz']:"";
      $asset_tag = $_POST['asset_tag'];
      $equipment_name = $_POST['equipment_name'];  
      $equipment_description = $_POST['equipment_description'];  
      $quantity_on_hand = $_POST['quantity_on_hand'];  
      $price = $_POST['price'];  
      $warranty = $_POST['warranty'];
      $uom_id = $_POST['uom_id'];
      $brand_id = $_POST['brand_id'];
      $category_id = $_POST['category_id'];
      $clinic_id = $_POST['clinic_id'];
      $clinic_section_id = $_POST['clinic_section_id'];
      $sub_section_id = $_POST['sub_section_id'];
      $region_id = $_POST['region_id'];
      $manufacturer_id = $_POST['manufacturer_id'];
      $vendor_id = $_POST['vendor_id'];
      $po_number = $_POST['po_number'];
      $serial_number = $_POST['serial_number'];
      $model_number = $_POST['model_number'];
      $status_id = $_POST['status_id'];
      $status = $_POST['status'];
      $asset_type_id = $_POST['asset_type_id'];
      $date_acquired  = date("Y-m-d");
      $depreciation_value = $price;
      $query = ("UPDATE tbl_medical_equipment SET asset_tag='".$asset_tag."', equipment_name='".$equipment_name."', equipment_description='".$equipment_description."', quantity_on_hand='".$quantity_on_hand."', price='".$price."', warranty='".$warranty."', depreciation_value='".$depreciation_value."',  asset_type_id='".$asset_type_id."', uom_id='".$uom_id."',  brand_id='".$brand_id."', category_id='".$category_id."',  clinic_id='".$clinic_id."', clinic_section_id='".$clinic_section_id."',  sub_section_id='".$sub_section_id."', region_id='".$region_id."',  manufacturer_id='".$manufacturer_id."', vendor_id='".$vendor_id."', po_number='".$po_number."', serial_number='".$serial_number."', model_number='".$model_number."', date_acquired='".$date_acquired."', status_id='".$status_id."', user_id='".$user_id."', status='".$status."'  WHERE equipment_id = '".$equipment_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
        error2();
      }
      }
            else  if ($_FILES['primary_image']['name'] !== "" && $warranty == 'Under Preventive Maintenance')
      {
      $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
      date_default_timezone_set("Asia/Manila");
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $equipment_id= isset($_POST['equipment_idz'])? $_POST['equipment_idz']:"";
      $asset_tag = $_POST['asset_tag'];
      $equipment_name = $_POST['equipment_name'];  
      $equipment_description = $_POST['equipment_description'];  
      $quantity_on_hand = $_POST['quantity_on_hand'];  
      $price = $_POST['price'];  
      $warranty = $_POST['warranty'];
      $uom_id = $_POST['uom_id'];
      $brand_id = $_POST['brand_id'];
      $category_id = $_POST['category_id'];
      $clinic_id = $_POST['clinic_id'];
      $clinic_section_id = $_POST['clinic_section_id'];
      $sub_section_id = $_POST['sub_section_id'];
      $region_id = $_POST['region_id'];
      $manufacturer_id = $_POST['manufacturer_id'];
      $vendor_id = $_POST['vendor_id'];
      $po_number = $_POST['po_number'];
      $serial_number = $_POST['serial_number'];
      $model_number = $_POST['model_number'];
      $status_id = $_POST['status_id'];
      $status = $_POST['status'];
      $asset_type_id = $_POST['asset_type_id'];
      $date_acquired  = date("Y-m-d");
      $depreciation_value = $price;
      $primary_image = addslashes(file_get_contents($_FILES["primary_image"]["tmp_name"]));
      $query = ("UPDATE tbl_medical_equipment SET asset_tag='".$asset_tag."', equipment_name='".$equipment_name."',  primary_image='".$primary_image."', equipment_description='".$equipment_description."', quantity_on_hand='".$quantity_on_hand."', price='".$price."', warranty='".$warranty."', depreciation_value='".$depreciation_value."',  asset_type_id='".$asset_type_id."', uom_id='".$uom_id."',  brand_id='".$brand_id."', category_id='".$category_id."',  clinic_id='".$clinic_id."', clinic_section_id='".$clinic_section_id."',  sub_section_id='".$sub_section_id."', region_id='".$region_id."',  manufacturer_id='".$manufacturer_id."', vendor_id='".$vendor_id."', po_number='".$po_number."', serial_number='".$serial_number."', model_number='".$model_number."', date_acquired='".$date_acquired."', status_id='".$status_id."', user_id='".$user_id."', status='".$status."'  WHERE equipment_id = '".$equipment_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
        error2();
      }
      }
            else  if ($_FILES['primary_image']['name'] == "" && $warranty == 'Under Preventive Maintenance')
      {
      $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
      date_default_timezone_set("Asia/Manila");
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $equipment_id= isset($_POST['equipment_idz'])? $_POST['equipment_idz']:"";
      $asset_tag = $_POST['asset_tag'];
      $equipment_name = $_POST['equipment_name'];  
      $equipment_description = $_POST['equipment_description'];  
      $quantity_on_hand = $_POST['quantity_on_hand'];  
      $price = $_POST['price'];  
      $warranty = $_POST['warranty'];
      $uom_id = $_POST['uom_id'];
      $brand_id = $_POST['brand_id'];
      $category_id = $_POST['category_id'];
      $clinic_id = $_POST['clinic_id'];
      $clinic_section_id = $_POST['clinic_section_id'];
      $sub_section_id = $_POST['sub_section_id'];
      $region_id = $_POST['region_id'];
      $manufacturer_id = $_POST['manufacturer_id'];
      $vendor_id = $_POST['vendor_id'];
      $po_number = $_POST['po_number'];
      $serial_number = $_POST['serial_number'];
      $model_number = $_POST['model_number'];
      $status_id = $_POST['status_id'];
      $status = $_POST['status'];
      $asset_type_id = $_POST['asset_type_id'];
      $date_acquired  = date("Y-m-d");
      $depreciation_value = $price;
      $query = ("UPDATE tbl_medical_equipment SET asset_tag='".$asset_tag."', equipment_name='".$equipment_name."', equipment_description='".$equipment_description."', quantity_on_hand='".$quantity_on_hand."', price='".$price."', warranty='".$warranty."', depreciation_value='".$depreciation_value."',  asset_type_id='".$asset_type_id."', uom_id='".$uom_id."',  brand_id='".$brand_id."', category_id='".$category_id."',  clinic_id='".$clinic_id."', clinic_section_id='".$clinic_section_id."',  sub_section_id='".$sub_section_id."', region_id='".$region_id."',  manufacturer_id='".$manufacturer_id."', vendor_id='".$vendor_id."', po_number='".$po_number."', serial_number='".$serial_number."', model_number='".$model_number."', date_acquired='".$date_acquired."', status_id='".$status_id."', user_id='".$user_id."',  status='".$status."'  WHERE equipment_id = '".$equipment_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
        error2();
      }
      }
  function succ()
    {
      echo '<script>
      swal({
        title: "Updated Successfully",
        type: "success",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "medicalequipment.php ";
      });
      </script>';
    }
    function error2()
    {
      echo '<script>
      swal({
        title: "Error!!!..",
        type: "error",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "medicalequipment.php ";
      });
      </script>';
    }  
 ?>  
