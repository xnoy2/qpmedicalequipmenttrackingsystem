<!DOCTYPE html>
<html>
	<head>
		<title></title>
	</head>
			<link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
		<script type="text/javascript" src="dist/sweetalert-dev.js"></script>
	<body>
	</body>
</html>
<?php
	session_start();
	require_once 'connect.php';

	$username=$_POST['username'];
	$password=$_POST['password'];

	if (empty($username) || empty($password))
	{
		header ('location:index.php');
	}
	else
	{
		$sql="SELECT user_id, user_type FROM tbl_user  WHERE username=? AND password=?";
		$qry=$DbConnect->prepare($sql);
		$qry->bind_param("ss",$username,$password);
		$qry->bind_result($user_id,$user_type);
		$qry->execute();
		$count=0;

		while ($qry->fetch()) 
		{
			$count++;
			$_SESSION['user_id'] = $user_id;
		}

		if ($count==1)
		{
			if ($user_type == "Administrator")
			{
			succ();
			}
			else if ($user_type == "Encoder")
			{
				succ1();
			}
			else
			{
				succ2();
			}
		}
		else
		{
			error1();
		}
	}
	function error1()
		{
			echo '<script>
			swal({
				title: "Incorrect Username, Password",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "index.php ";
			});
			</script>';
		}
		function succ()
		{
			echo '<script>
			swal({
				title: "Login Successfully",
				type: "success",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "dashboard.php ";
			});
			</script>';
		}
		function succ1()
		{
			echo '<script>
			swal({
				title: "Login Successfully",
				type: "success",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "encoder/dashboard.php ";
			});
			</script>';
		}
				function succ2()
		{
			echo '<script>
			swal({
				title: "Login Successfully",
				type: "success",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "dashboard2.php ";
			});
			</script>';
		}
?>