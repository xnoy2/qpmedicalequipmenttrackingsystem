<?php
	$conn=mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
	
	if(!$conn){
		die("Error: Failed to connect to database!");
	}
?>