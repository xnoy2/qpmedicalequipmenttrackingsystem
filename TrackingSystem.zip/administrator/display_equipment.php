<?php  
include 'connect.php';
date_default_timezone_set("Asia/Manila");
$connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");  
$user_id = $_SESSION['user_id'];
$sql = "SELECT tbl_medical_equipment.equipment_id, tbl_medical_equipment.equipment_name, tbl_medical_equipment.asset_tag, tbl_medical_equipment.primary_image, tbl_medical_equipment.equipment_description, tbl_medical_equipment.quantity_on_hand, tbl_medical_equipment.warranty, tbl_medical_equipment.depreciation_value,tbl_medical_equipment.status, tbl_uom.uom_id, tbl_uom.uom_name, tbl_brand.brand_id, tbl_brand.brand_name, tbl_category.category_id, tbl_category.category_name, tbl_clinic.clinic_id, tbl_clinic.clinic_name, tbl_section.clinic_section_id, tbl_section.section_name, tbl_sub_section.sub_section_id, tbl_sub_section.sub_section_name, tbl_region.region_id, tbl_region.region_name, tbl_manufacturer.manufacturer_id, tbl_manufacturer.manufacturer_name, tbl_vendor.vendor_id, tbl_vendor.vendor_name, tbl_medical_equipment.po_number, tbl_medical_equipment.serial_number, tbl_medical_equipment.model_number, tbl_medical_equipment.price, tbl_medical_equipment.date_acquired, tbl_status.status_id, tbl_status.status_name, tbl_user.user_id, tbl_user.full_name, tbl_asset_type.asset_type_id, tbl_asset_type.type_name

FROM tbl_status INNER JOIN (tbl_vendor INNER JOIN (tbl_manufacturer INNER JOIN (tbl_region INNER JOIN (tbl_sub_section INNER JOIN (tbl_section INNER JOIN (tbl_clinic INNER JOIN (tbl_category INNER JOIN (tbl_brand INNER JOIN (tbl_user INNER JOIN (tbl_uom INNER JOIN (tbl_asset_type INNER JOIN tbl_medical_equipment ON tbl_asset_type.asset_type_id = tbl_medical_equipment.asset_type_id) ON tbl_uom.uom_id = tbl_medical_equipment.uom_id) ON tbl_user.user_id = tbl_medical_equipment.user_id) ON tbl_brand.brand_id = tbl_medical_equipment.brand_id) ON tbl_category.category_id = tbl_medical_equipment.category_id) ON tbl_clinic.clinic_id = tbl_medical_equipment.clinic_id) ON tbl_section.clinic_section_id = tbl_medical_equipment.clinic_section_id) ON tbl_sub_section.sub_section_id = tbl_medical_equipment.sub_section_id) ON tbl_region.region_id = tbl_medical_equipment.region_id) ON tbl_manufacturer.manufacturer_id = tbl_medical_equipment.manufacturer_id) ON tbl_vendor.vendor_id = tbl_medical_equipment.vendor_id) ON tbl_status.status_id = tbl_medical_equipment.status_id WHERE tbl_medical_equipment.status = 'Approved'
GROUP BY tbl_medical_equipment.equipment_id, tbl_medical_equipment.asset_tag, tbl_medical_equipment.equipment_name, tbl_medical_equipment.primary_image, tbl_medical_equipment.equipment_description, tbl_medical_equipment.quantity_on_hand, tbl_medical_equipment.price, tbl_medical_equipment.warranty, tbl_medical_equipment.depreciation_value,tbl_medical_equipment.status, tbl_asset_type.type_name, tbl_uom.uom_name, tbl_brand.brand_name, tbl_category.category_name, tbl_clinic.clinic_name, tbl_section.section_name, tbl_sub_section.sub_section_name, tbl_region.region_name, tbl_manufacturer.manufacturer_name, tbl_vendor.vendor_name, tbl_medical_equipment.po_number, tbl_medical_equipment.serial_number, tbl_medical_equipment.model_number, tbl_medical_equipment.date_acquired, tbl_status.status_name, tbl_user.full_name,  tbl_asset_type.asset_type_id, tbl_asset_type.type_name ASC;";
$qry=$DbConnect->prepare($sql);
$qry->bind_result($equipment_id,$asset_tag,$equipment_name,$primary_image,$equipment_description,$quantity_on_hand,$price,$warranty,$depreciation_value,$type_name,$status,$uom_id,$uom_name,$brand_id,$brand_name,$category_id,$category_name,$clinic_id,$clinic_name,$clinic_section_id,$section_name,$sub_section_id,$sub_section_name,$region_id,$region_name,$manufacturer_id,$manufacturer_name,$vendor_id,$vendor_name,$po_number,$serial_number,$model_number,$date_acquired,$status,$status_name,$full_name,$asset_type_id,$type_name);
$qry->execute();
$result = mysqli_query($connect, $sql);  

while($row = mysqli_fetch_array($result))
  { 
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_id,full_name FROM tbl_user WHERE user_id=?";
    ?>
      <tr>
        <td><?php printf ("%s", $row["asset_tag"]); ?> </td>
        <td><?php printf ("%s", $row["equipment_name"]); ?> </td>
        <td><?php printf ("%s", $row["equipment_description"]); ?> </td>
        <?php echo '<td> <img src="data:image/jpeg;base64,'.base64_encode($row['primary_image'] ).'" height="50" width="50" class="img-square elevation-2" alt="User Image" /> </td>'; ?> 
         <td><b style="color:#007bff"><?php printf ("%s", $row["quantity_on_hand"]); ?> </b></td>
         <td><b style="color:#007bff"><?php printf ("%s", $row["warranty"]); ?> </b></td>
         <td><b style="color: blue"><i><?php printf ("%s", $row["price"]); ?></i></b> </td>
         <td><b style="color: blue"><?php printf ("%s", $row["depreciation_value"]); ?> </b></td>
         <td><?php printf ("%s", $row["uom_name"]); ?> </td>
         <td><?php printf ("%s", $row["brand_name"]); ?> </td>
         <td><?php printf ("%s", $row["category_name"]); ?> </td>
         <td><?php printf ("%s", $row["type_name"]); ?> </td>
         <td><?php printf ("%s", $row["clinic_name"]); ?> </td>
         <td><?php printf ("%s", $row["section_name"]); ?> </td>
         <td><?php printf ("%s", $row["sub_section_name"]); ?> </td>
         <td><?php printf ("%s", $row["region_name"]); ?> </td>
         <td><?php printf ("%s", $row["manufacturer_name"]); ?> </td>
         <td><?php printf ("%s", $row["vendor_name"]); ?> </td>
         <td><?php printf ("%s", $row["status_name"]); ?> </td>
         <td><?php printf ("%s", $row["po_number"]); ?> </td>
         <td><?php printf ("%s", $row["serial_number"]); ?> </td>
         <td><?php printf ("%s", $row["model_number"]); ?> </td>
         <td><?php $date_acquired=strtotime($row['date_acquired']);
          echo date("M-d-Y",$date_acquired)?></td>
         <td><?php printf ("%s", $row["full_name"]); ?> </td>
         <td>
         <a href="viewimage.php? equipment_id=<?php printf ("%s", $row["equipment_id"]); ?>"><button type='button' class='btn btn-primary btn-xs'><i class='fa fa-image'></i> 
            </button> </a>
              <button type='button' class='btn btn-info btn-xs' data-toggle='modal' data-target='#update<?php printf ("%s", $row["equipment_id"]); ?>'><i class='fa fa-pencil-alt'></i> 
              </button>
          <button type='button' class='btn btn-xs btn-danger ' data-toggle='modal' data-target='#delete<?php printf ("%s", $row["equipment_id"]); ?>'><i class="fa fa-trash "></i>  </button>
        </td>
              
      </tr>
        <div class="modal fade" id="update<?php printf ("%s", $row["equipment_id"]); ?>">
                        <div class="modal-dialog modal-lg">
                           <form action="update_medical_equipment.php"  method="post" id="form1<?php printf ("%s", $row["equipment_id"]); ?>" enctype="multipart/form-data" name="form1" >
                        <input type="hidden" name="user_idz" value="<?php echo $user_id; ?>">
                          <input type="hidden" name="equipment_idz" value="<?php printf ("%s", $row["equipment_id"]); ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Update Medical Equipment</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="row">
                                  <div class="col-3">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Asset Tag</label>
                                  <input type="text" class="form-control" id="" name="asset_tag"  value="<?php printf ("%s", $row["asset_tag"]); ?>">
                                </div>
                              </div>
                                <div class="col-4">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Equipment</label>
                                  <input type="text" class="form-control" id="" name="equipment_name"  value="<?php printf ("%s", $row["equipment_name"]); ?>">
                                </div>
                              </div>
                                <div class="col-5">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Description</label>
                                  <textarea class="form-control" rows="2" name="equipment_description" ><?php printf ("%s", $row["equipment_description"]); ?></textarea>
                                </div>
                              </div>
                               
                              <div class="col-2">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Qty</label>
                                  <input type="number" class="form-control" id=""  name="quantity_on_hand" value="<?php printf ("%s", $row["quantity_on_hand"]); ?>">
                                </div>
                              </div>
                              <div class="col-4">
                                  <div class="form-group">
                                  <label>Warranty</label>
                                  <select class="form-control" name="warranty">
                                    <?php 
                                  if ($row["warranty"] == "5 Years")
                                  {
                                ?>
                                <option selected="selected">5 Years</option>
                                <option>10 Years</option>
                                <option>No Warranty</option>
                                <option>Under Preventive Maintenance</option>

                                <?php 
                                  }
                                  else if ($row["warranty"] == "10 Years")
                                  {
                                    ?>
                                   <option selected="selected">10 Years</option>
                                    <option >5 Years</option>
                                    <option>No Warranty</option>
                                <option>Under Preventive Maintenance</option>
                              <?php 
                                  }
                                  else if ($row["warranty"] == "No Warranty")
                                  {
                                    ?>
                                   <option selected="selected">No Warranty</option>
                                    <option >5 Years</option>
                                    <option>10 Years</option>
                                  <option>Under Preventive Maintenance</option>
                                <?php 
                              }
                              else if ($row["warranty"] == "Under Preventive Maintenance")
                                  {
                                    ?>
                                   <option selected="selected">Under Preventive Maintenance</option>
                                    <option >5 Years</option>
                                    <option>10 Years</option>
                                  <option>No Warranty</option>
                                <?php 
                              }
                              else
                              {
                              ?>
                                    <option >5 Years</option>
                                    <option>10 Years</option>
                                  <option>No Warranty</option>
                                  <option>Under Preventive Maintenance</option>
                                <?php 
                              }
                                  ?>
                                  </select>
                                </div>
                              </div>
                              <div class="col-3">
                                  <div class="form-group">
                                  <label>UOM</label>
                                  <select class="form-control select2" name="uom_id">
                                    <option selected="" value=<?php printf ("%s", $row["uom_id"]); ?>><?php printf ("%s", $row["uom_name"]); ?></option>
                                    <?php
                                   include 'connect.php';
                                    $sql="SELECT tbl_uom.uom_id,tbl_uom.uom_name FROM tbl_uom ORDER BY tbl_uom.uom_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($uom_id,$uom_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $uom_id ?>"><?php echo $uom_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-3">
                                  <div class="form-group">
                                  <label>Brand</label>
                                  <select class="form-control select2" name="brand_id">
                                    <option selected="" value=<?php printf ("%s", $row["brand_id"]); ?>><?php printf ("%s", $row["brand_name"]); ?></option>
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_brand.brand_id,tbl_brand.brand_name FROM tbl_brand ORDER BY tbl_brand.brand_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($brand_id,$brand_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $brand_id ?>"><?php echo $brand_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-4">
                                  <div class="form-group">
                                  <label>Category</label>
                                  <select class="form-control select2" name="category_id">
                                    <option selected=""  value=<?php printf ("%s", $row["category_id"]); ?>><?php printf ("%s", $row["category_name"]); ?></option>
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_category.category_id,tbl_category.category_name FROM tbl_category ORDER BY tbl_category.category_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($category_id,$category_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $category_id ?>"><?php echo $category_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                               <div class="col-4">
                                  <div class="form-group">
                                  <label>Asset Type</label>
                                  <select class="form-control select2" name="asset_type_id">
                                    <option selected="" value=<?php printf ("%s", $row["asset_type_id"]); ?>><?php printf ("%s", $row["type_name"]); ?></option>
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_asset_type.asset_type_id,tbl_asset_type.type_name FROM tbl_asset_type ORDER BY tbl_asset_type.type_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($asset_type_id,$type_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $asset_type_id ?>"><?php echo $type_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                                <div class="col-4">
                                  <div class="form-group">
                                  <label>Region</label>
                                  <select class="form-control select2" name="region_id">
                                    <option selected="" value=<?php printf ("%s", $row["region_id"]); ?>><?php printf ("%s", $row["region_name"]); ?></option>
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_region.region_id,tbl_region.region_name FROM tbl_region ORDER BY tbl_region.region_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($region_id,$region_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $region_id ?>"><?php echo $region_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-4">
                                  <div class="form-group">
                                  <label>Clinic</label>
                                  <select class="form-control select2" name="clinic_id" >
                                    <option selected="" value=<?php printf ("%s", $row["clinic_id"]); ?>><?php printf ("%s", $row["clinic_name"]); ?></option>
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_clinic.clinic_id,tbl_clinic.clinic_name FROM tbl_clinic ORDER BY tbl_clinic.clinic_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($clinic_id,$clinic_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $clinic_id ?>"><?php echo $clinic_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-4">
                                  <div class="form-group">
                                  <label>Clinic Section</label>
                                  <select class="form-control select2" name="clinic_section_id">
                                    <option selected="" value=<?php printf ("%s", $row["clinic_section_id"]); ?>><?php printf ("%s", $row["section_name"]); ?></option>
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_section.clinic_section_id,tbl_section.section_name FROM tbl_section ORDER BY tbl_section.section_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($clinic_section_id,$section_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $clinic_section_id ?>"><?php echo $section_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-4">
                                  <div class="form-group">
                                  <label>Clinic Sub Section</label>
                                  <select class="form-control select2" name="sub_section_id">
                                    <option selected="" value=<?php printf ("%s", $row["sub_section_id"]); ?>><?php printf ("%s", $row["sub_section_name"]); ?></option>
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_sub_section.sub_section_id,tbl_sub_section.sub_section_name FROM tbl_sub_section ORDER BY tbl_sub_section.sub_section_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($sub_section_id,$sub_section_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $sub_section_id ?>"><?php echo $sub_section_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                            
                              <div class="col-3">
                                  <div class="form-group">
                                  <label>Manufacturer</label>
                                  <select class="form-control select2" name="manufacturer_id">
                                    <option selected="" value=<?php printf ("%s", $row["manufacturer_id"]); ?>><?php printf ("%s", $row["manufacturer_name"]); ?></option>
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_manufacturer.manufacturer_id,tbl_manufacturer.manufacturer_name FROM tbl_manufacturer ORDER BY tbl_manufacturer.manufacturer_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($manufacturer_id,$manufacturer_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $manufacturer_id ?>"><?php echo $manufacturer_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-3">
                                  <div class="form-group">
                                  <label>Vendor</label>
                                  <select class="form-control select2" name="vendor_id">
                                    <option selected="" value=<?php printf ("%s", $row["vendor_id"]); ?>><?php printf ("%s", $row["vendor_name"]); ?></option>
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_vendor.vendor_id,tbl_vendor.vendor_name FROM tbl_vendor ORDER BY tbl_vendor.vendor_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($vendor_id,$vendor_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $vendor_id ?>"><?php echo $vendor_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                             
                              <div class="col-3">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">PO Number</label>
                                  <input type="text" class="form-control" id="" name="po_number" value="<?php printf ("%s", $row["po_number"]); ?>">
                                </div>
                              </div>
                              <div class="col-3">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Serial Number</label>
                                  <input type="text" class="form-control" id="" name="serial_number"value="<?php printf ("%s", $row["serial_number"]); ?>">
                                </div>
                              </div>
                              <div class="col-3">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Model Number</label>
                                  <input type="text" class="form-control" id="" name="model_number" value="<?php printf ("%s", $row["model_number"]); ?>">
                                </div>
                              </div>
                              <div class="col-3">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Price</label>
                                  <input type="number" class="form-control" id="" name="price" value="<?php printf ("%s", $row["price"]); ?>">
                                </div>
                              </div>
                              <div class="col-3">
                                  <div class="form-group">
                                  <label>Item Condition</label>
                                  <select class="form-control select2" name="status_id">
                                    <option selected="" value=<?php printf ("%s", $row["status_id"]); ?>><?php printf ("%s", $row["status_name"]); ?></option>
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_status.status_id,tbl_status.status_name FROM tbl_status ORDER BY tbl_status.status_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($status_id,$status_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $status_id ?>"><?php echo $status_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                               <div class="col-3">
                                  <div class="form-group">
                                  <label>Status</label>
                                  <select class="form-control" name="status">
                                    <?php 
                                  if ($row["status"] == "Pending")
                                  {
                                ?>
                                <option selected="selected">Pending</option>
                                <option>Approved</option>
                                <option>Rejected</option>

                                <?php 
                                  }
                                  else if ($row["status"] == "Approved")
                                  {
                                    ?>
                                   <option selected="selected">Approved</option>
                                <option>Pending</option>
                                <option>Rejected</option>
                              <?php 
                                  }
                                  else
                                  {
                                    ?>
                                <option selected="selected">Rejected</option>
                                <option>Approved</option>
                                <option>Pending</option>
                                <?php 
                            }
                                  ?>
                                  </select>
                                </div>
                              </div>
                              <div class="col-6">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Select New Image</label><p style="margin-left: 34%; margin-top: -8%; color: blue">(Optional)</p>
                                  <input type="file" name="primary_image" id="primary_image">
                                </div>
                              </div>

                              
                              </div>
                            </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                            <input type="submit" name="primary_image" id="primary_image"  value="Update" class="btn btn-primary"  /> 
                           </div>
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                      <div class="modal fade" id="delete<?php printf ("%s", $row["equipment_id"]); ?>" style="margin-left: 30%; margin-top: 20%">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Are you sure you want delete this data?</h5>
              
            </div>
            
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> No!</button>
              <a href="delete_medical_equipment.php? equipment_id=<?php printf ("%s", $row["equipment_id"]); ?>"><button type="button" class="btn btn-primary"><i class="fa fa-check"></i> Yes!</button></a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>

          
<?php 
  }   
  
?>
