
<?php
  require_once("connect.php");
  $user_id = $_SESSION['user_id'];
  date_default_timezone_set("Asia/Manila");
  $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");  
$user_id = $_SESSION['user_id'];
  $sql="SELECT tbl_calibration_report.calibration_id, tbl_medical_equipment.equipment_id, tbl_medical_equipment.equipment_name, tbl_calibration_report.report_name, tbl_calibration_report.report_description, tbl_calibration_report.file_uploaded, tbl_calibration_report.uploaded_date, tbl_calibration_report.status, tbl_user.user_id, tbl_user.full_name
FROM tbl_calibration_report INNER JOIN tbl_user ON tbl_calibration_report.user_id=tbl_user.user_id INNER JOIN tbl_medical_equipment ON tbl_calibration_report.equipment_id=tbl_medical_equipment.equipment_id WHERE tbl_calibration_report.status = 'Pending' group by tbl_calibration_report.calibration_id, tbl_medical_equipment.equipment_id, tbl_medical_equipment.equipment_name, tbl_calibration_report.report_name, tbl_calibration_report.report_description, tbl_calibration_report.file_uploaded, tbl_calibration_report.uploaded_date, tbl_calibration_report.status, tbl_user.user_id, tbl_user.full_name;
;
";
  $qry=$DbConnect->prepare($sql);
  $qry->bind_result($calibration_id,$report_name,$equipment_id,$equipment_name,$report_description,$file_uploaded,$uploaded_date,$status,$user_id,$full_name);
$qry->execute();
$result = mysqli_query($connect, $sql);  
while($row = mysqli_fetch_array($result))
  { 
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_id,full_name FROM tbl_user WHERE user_id=?";
    ?>

      <tr>
      
        <td><b style="color: blue;"><?php printf ("%s", $row["equipment_name"]); ?> </b></td>
        <td><?php printf ("%s", $row["report_name"]); ?> </td>
        <td><?php printf ("%s", $row["report_description"]); ?> </td>
        <td>
          <a href="download.php?file_id=<?php printf ("%s", $row["calibration_id"]); ?>"><?php printf ("%s", $row["file_uploaded"]); ?></a>
        </td>
        <td><?php printf ("%s", $row["uploaded_date"]); ?></td>
        <td><?php printf ("%s", $row["full_name"]); ?> </td>
         <td>

        <button type='button' class='btn btn-info btn-xs' data-toggle='modal' data-target='#update<?php printf ("%s", $row["calibration_id"]); ?>'><i class='fa fa-pencil-alt'></i> 
              </button>
          <button type='button' class='btn btn-xs btn-danger ' data-toggle='modal' data-target='#delete<?php printf ("%s", $row["calibration_id"]); ?>'><i class="fa fa-trash "></i>  </button>
        </td>
              
      </tr>
      
                <div class="modal fade" id="update<?php printf ("%s", $row["calibration_id"]); ?>">
                        <div class="modal-dialog modal-md">
                            <form action="update_calibration_pending.php" id="form1<?php printf ("%s", $row["calibration_id"]); ?>" name="form1" method="post" enctype="multipart/form-data" >
                            <input type="hidden" name="calibration_idz" value="<?php printf ("%s", $row["calibration_id"]); ?>">
                            <input type="hidden" name="user_idz" value="<?php echo $user_id; ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Update Calibration Report</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="row">
                                <div class="col-6">
                                   <div class="form-group">
                                  <label for="exampleInputEmail1">Equipment</label>
                                  <select class="form-control" name="equipment_id">
                                    <option selected="" value="<?php printf ("%s", $row["equipment_id"]); ?>"><?php printf ("%s", $row["equipment_name"]); ?></option>
                                    <?php
                                    include 'connect.php';
                                    $sql="SELECT tbl_medical_equipment.equipment_id,tbl_medical_equipment.equipment_name FROM tbl_medical_equipment WHERE tbl_medical_equipment.status = 'Approved' ORDER BY tbl_medical_equipment.equipment_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($equipment_id,$equipment_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $equipment_id ?>"><?php echo $equipment_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                                <div class="col-6">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Report</label>
                                  <input type="text" class="form-control" id="" name="report_name" value="<?php printf ("%s", $row["report_name"]); ?>">
                                </div>
                              </div>
                                <div class="col-12">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Description</label>
                                  <textarea class="form-control" rows="3" name="report_description"  placeholder="Enter ..."><?php printf ("%s", $row["report_description"]); ?></textarea>
                                </div>
                              </div>
                              <div class="col-6">
                                   <div class="form-group">
                                  <label for="exampleInputEmail1">Status</label>
                                  <select class="form-control" name="status">
                                    <?php 
                                  if ($row["status"] == "Pending")
                                  {
                                ?>
                                <option selected="selected">Pending</option>
                                <option>Approved</option>

                                <?php 
                                  }
                                  else if ($row["status"] == "Approved")
                                  {
                                    ?>
                                   <option selected="selected">Approved</option>
                                <option>Pending</option>
                              <?php 
                                  }
                                  ?>
                                  </select>
                                </div>
                              </div>
                               <div class="col-12">
                                <div class="form-group">
                                   <label for="exampleInputEmail1">Select New File</label><p style="margin-left: 24%; margin-top: -7%; color: blue">(Optional)</p>
                                  <input type="file" name="file_uploaded">
                                </div>
                              </div>
                              </div>
                            </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                              <button type="submit" onclick="form1<?php printf ("%s", $row["calibration_id"]); ?>.submit();" form="form1" class="btn btn-primary"><i class="fa fa-check"></i> Update</button>    
                            </div>
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                
                      <div class="modal fade" id="delete<?php printf ("%s", $row["calibration_id"]); ?>" style="margin-left: 30%; margin-top: 20%">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Are you sure you want delete this data?</h5>
              
            </div>
            
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> No!</button>
              <a href="delete_calibration.php?calibration_id=<?php printf ("%s", $row["calibration_id"]); ?>"><button type="button" class="btn btn-primary"><i class="fa fa-check"></i> Yes!</button></a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
         
        
          
<?php 
  }   
  
?>
