
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
        <script type="text/javascript" src="dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>

</html>
<?php
require_once 'connect.php';
$manufacturer_id= isset($_POST['manufacturer_idz'])? $_POST['manufacturer_idz']:"";
$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
$manufacturer_name=$_POST['manufacturer_name'];
$manufacturer_address=$_POST['manufacturer_address'];
$manufacturer_contact =$_POST['manufacturer_contact'];
        $sql1 = "SELECT * FROM tbl_medical_equipment WHERE manufacturer_id=?";
            $qry1 =$DbConnect->prepare($sql1);
            $qry1->bind_param("s",$manufacturer_id);
            $qry1->execute();
            $qry1->store_result();
            $qry1->fetch();
            if ($qry1->num_rows()<=0)
                {
if (!empty($manufacturer_name) && !empty($manufacturer_address) && !empty($manufacturer_contact))
{
    $sql = "UPDATE tbl_manufacturer SET manufacturer_name=?, manufacturer_address=?, manufacturer_contact=?, user_id=? WHERE manufacturer_id=?";
    $qry =$DbConnect->prepare($sql);
    $qry->bind_param("sssss",$manufacturer_name,$manufacturer_address,$manufacturer_contact,$user_id,$manufacturer_id);
    if ($qry->execute())
    {
     succ();    
    }
}
else 
{
    err();
}
}
else
{
    err2();
}
function succ()
        {
            echo '<script>
            swal({
                title: "Updated Successfully",
                type: "success",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "manufacturer.php ";
            });
            </script>';
        }
        function err()
        {
            echo '<script>
            swal({
                title: "Error!!...",
                type: "error",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "manufacturer.php ";
            });
            </script>';
        }
        function err2()
        {
            echo '<script>
            swal({
                title: "Cant Update this item. It might already exist in equipment record",
                type: "warning",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "manufacturer.php ";
            });
            </script>';
        }
        ?>