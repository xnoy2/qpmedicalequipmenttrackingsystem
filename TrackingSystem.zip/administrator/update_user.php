
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
        <script type="text/javascript" src="dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>
 <script>  
 $(document).ready(function(){  
      $('#insert').click(function(){  
           var image_name = $('#avatar').val();  
           if(image_name == '')  
           {  
                alert("Please Select Image");  
                return false;  
           }  
           else  
           {  
                var extension = $('#avatar').val().split('.').pop().toLowerCase();  
                if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)  
                {  
                     alert('Invalid Image File');  
                     $('#avatar').val('');  
                     return false;  
                }  
           }  
      });  
 });  
 </script>   
</html>
<?php
include 'connect.php';
 $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");  
    if($_FILES['avatar']['name'] == "")
    {
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $full_name = $_POST['full_name'];
      $email = $_POST['email'];  
      $contact = $_POST['contact'];  
      $username = $_POST['username'];  
      $user_type = $_POST['user_type'];
      $status = $_POST['status'];
      $query = ("UPDATE tbl_user SET full_name='".$full_name."', email='".$email."', contact='".$contact."', username='".$username."', user_type='".$user_type."', status='".$status."' WHERE user_id = '".$user_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
        error2();
      }
  }
    else
    {
      include 'connect.php';
      $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");  
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $full_name = $_POST['full_name'];
      $email = $_POST['email'];  
      $contact = $_POST['contact'];  
      $username = $_POST['username'];  
      $user_type = $_POST['user_type'];
      $status = $_POST['status'];
      $avatar = addslashes(file_get_contents($_FILES["avatar"]["tmp_name"]));
      $query = ("UPDATE tbl_user SET full_name='".$full_name."', email='".$email."', contact='".$contact."', username='".$username."', user_type='".$user_type."', avatar='".$avatar."', status='".$status."' WHERE user_id = '".$user_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
      error2();
      }
    }
  function succ()
    {
      echo '<script>
      swal({
        title: "Updated Successfully",
        type: "success",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "user.php ";
      });
      </script>';
    }
    function error2()
    {
      echo '<script>
      swal({
        title: "Error!!!..",
        type: "error",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "user.php ";
      });
      </script>';
    }  
 ?>  
