
<?php  
include 'connect.php';
date_default_timezone_set("Asia/Manila");
$connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");  
$user_id = $_SESSION['user_id'];
$sql = "SELECT tbl_medical_equipment.equipment_id, tbl_medical_equipment.equipment_name, tbl_medical_equipment.asset_tag, tbl_medical_equipment.primary_image, tbl_medical_equipment.equipment_description, tbl_medical_equipment.quantity_on_hand, tbl_medical_equipment.warranty, tbl_medical_equipment.depreciation_value,tbl_medical_equipment.status, tbl_uom.uom_id, tbl_uom.uom_name, tbl_brand.brand_id, tbl_brand.brand_name, tbl_category.category_id, tbl_category.category_name, tbl_clinic.clinic_id, tbl_clinic.clinic_name, tbl_section.clinic_section_id, tbl_section.section_name, tbl_sub_section.sub_section_id, tbl_sub_section.sub_section_name, tbl_region.region_id, tbl_region.region_name, tbl_manufacturer.manufacturer_id, tbl_manufacturer.manufacturer_name, tbl_vendor.vendor_id, tbl_vendor.vendor_name, tbl_medical_equipment.po_number, tbl_medical_equipment.serial_number, tbl_medical_equipment.model_number, tbl_medical_equipment.price, tbl_medical_equipment.date_acquired, tbl_status.status_id, tbl_status.status_name, tbl_user.user_id, tbl_user.full_name, tbl_asset_type.asset_type_id, tbl_asset_type.type_name

FROM tbl_status INNER JOIN (tbl_vendor INNER JOIN (tbl_manufacturer INNER JOIN (tbl_region INNER JOIN (tbl_sub_section INNER JOIN (tbl_section INNER JOIN (tbl_clinic INNER JOIN (tbl_category INNER JOIN (tbl_brand INNER JOIN (tbl_user INNER JOIN (tbl_uom INNER JOIN (tbl_asset_type INNER JOIN tbl_medical_equipment ON tbl_asset_type.asset_type_id = tbl_medical_equipment.asset_type_id) ON tbl_uom.uom_id = tbl_medical_equipment.uom_id) ON tbl_user.user_id = tbl_medical_equipment.user_id) ON tbl_brand.brand_id = tbl_medical_equipment.brand_id) ON tbl_category.category_id = tbl_medical_equipment.category_id) ON tbl_clinic.clinic_id = tbl_medical_equipment.clinic_id) ON tbl_section.clinic_section_id = tbl_medical_equipment.clinic_section_id) ON tbl_sub_section.sub_section_id = tbl_medical_equipment.sub_section_id) ON tbl_region.region_id = tbl_medical_equipment.region_id) ON tbl_manufacturer.manufacturer_id = tbl_medical_equipment.manufacturer_id) ON tbl_vendor.vendor_id = tbl_medical_equipment.vendor_id) ON tbl_status.status_id = tbl_medical_equipment.status_id WHERE tbl_medical_equipment.status = 'Approved'
GROUP BY tbl_medical_equipment.equipment_id, tbl_medical_equipment.asset_tag, tbl_medical_equipment.equipment_name, tbl_medical_equipment.primary_image, tbl_medical_equipment.equipment_description, tbl_medical_equipment.quantity_on_hand, tbl_medical_equipment.price, tbl_medical_equipment.warranty, tbl_medical_equipment.depreciation_value,tbl_medical_equipment.status, tbl_asset_type.type_name, tbl_uom.uom_name, tbl_brand.brand_name, tbl_category.category_name, tbl_clinic.clinic_name, tbl_section.section_name, tbl_sub_section.sub_section_name, tbl_region.region_name, tbl_manufacturer.manufacturer_name, tbl_vendor.vendor_name, tbl_medical_equipment.po_number, tbl_medical_equipment.serial_number, tbl_medical_equipment.model_number, tbl_medical_equipment.date_acquired, tbl_status.status_name, tbl_user.full_name,  tbl_asset_type.asset_type_id, tbl_asset_type.type_name ASC;";
$qry=$DbConnect->prepare($sql);
$qry->bind_result($equipment_id,$asset_tag,$equipment_name,$primary_image,$equipment_description,$quantity_on_hand,$price,$warranty,$depreciation_value,$type_name,$status,$uom_id,$uom_name,$brand_id,$brand_name,$category_id,$category_name,$clinic_id,$clinic_name,$clinic_section_id,$section_name,$sub_section_id,$sub_section_name,$region_id,$region_name,$manufacturer_id,$manufacturer_name,$vendor_id,$vendor_name,$po_number,$serial_number,$model_number,$date_acquired,$status,$status_name,$full_name,$asset_type_id,$type_name);
$qry->execute();
$result = mysqli_query($connect, $sql);  
while($row = mysqli_fetch_array($result))
  { 

    ?>
      <tr>
        <td><input type="checkbox" name="check[]" id="check" value="<?php printf ("%s", $row["equipment_id"]); ?> "> </td>
        <?php echo '<td> <img src="data:image/jpeg;base64,'.base64_encode($row['primary_image'] ).'" height="40" width="40" class="img-square elevation-3" alt="User Image" /> </td>'; ?> 
        <td><?php printf ("%s", $row["asset_tag"]); ?> </td>
        <td><?php printf ("%s", $row["equipment_name"]); ?> </td>
        <td><?php printf ("%s", $row["equipment_description"]); ?> </td>
         <td><b style="color:#007bff"><?php printf ("%s", $row["warranty"]); ?> </b></td>
         <td><b style="color:#007bff"><?php printf ("%s", $row["price"]); ?> </b></td>
         <td><b style="color: blue"><?php printf ("%s", $row["depreciation_value"]); ?> </b></td>
      </tr>
          
<?php 
  }   
  
?>
