<?php  
include 'connect.php';
$connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");  
$sql = "SELECT user_id,full_name,email,contact,username,password,user_type,avatar,status FROM tbl_user";
$qry=$DbConnect->prepare($sql);
$qry->bind_result($user_id,$full_name,$email,$contact,$username,$password,$user_type,$avatar,$status);
$qry->execute();
$result = mysqli_query($connect, $sql);  
while($row = mysqli_fetch_array($result))
  { 
    ?>
      <tr>
      	<?php echo '<td> <img src="data:image/jpeg;base64,'.base64_encode($row['avatar'] ).'" height="50" width="50" class="img-square elevation-2" alt="User Image" /> </td>'; ?> 
        <?php if ($row['status'] !== "1")
        {
          ?>
          <td><b style="color:red"><?php printf ("%s", $row["full_name"]); ?></b> </td>
          <?php
        }
        else
        {
        ?>
         <td><b style="color:#455a5a"><?php printf ("%s", $row["full_name"]); ?></b> </td>
         <?php
       }
       ?>
        <td><?php printf ("%s", $row["username"]); ?> </td>
        <td><?php echo "******" ?> </td>
        <td><?php printf ("%s", $row["contact"]);; ?> </td>
        <td><i  style="color: blue"><u><?php printf ("%s", $row["email"]); ?></u></i> </td>
        <td><?php printf ("%s", $row["user_type"]); ?> </td>
         <td>
          <button type='button' class='btn btn-warning btn-xs' data-toggle='modal' data-target='#password<?php printf ("%s", $row["user_id"]); ?>'><i class='fa fa-unlock'></i> 
              </button> 
        <button type='button' class='btn btn-info btn-xs' data-toggle='modal' data-target='#update<?php printf ("%s", $row["user_id"]); ?>'><i class='fa fa-pencil-alt'></i> 
              </button>
          <button type='button' class='btn btn-xs btn-danger ' data-toggle='modal' data-target='#delete<?php printf ("%s", $row["user_id"]); ?>'><i class="fa fa-trash "></i>  </button>
        </td>
              
      </tr>
         <div class="modal fade" id="update<?php printf ("%s", $row["user_id"]); ?>">
                        <div class="modal-dialog modal-md">
                            <form action="update_user.php"  method="post" id="form1<?php printf ("%s", $row["user_id"]); ?>" enctype="multipart/form-data" name="form1" >
                         <input type="hidden" name="user_idz" value="<?php printf ("%s", $row["user_id"]); ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Update User</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="row">
                                  <div class="col-8">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Fullname</label>
                                  <input type="text" class="form-control" id="" name="full_name" value="<?php printf ("%s", $row["full_name"]); ?>" >
                                </div>
                                  
                              </div>
                               <div class="col-4">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">User Type</label>
                                  <select class="form-control" name="status">
                                   <?php
                                   if ($row['status'] == "1")
                                   {
                                     ?>
                                   <option  value="1" selected="">Active</option>
                                   <?php
                               }
                               else if ($row['status'] !== "1")
                                {
                                  ?>
                                   <option value="2" selected="">Inactive</option>
                                   <option value="1">Active</option>
                                   <?php
                               }
        
                           ?>
                                </select>
                                </div>
                              </div>
                                <div class="col-6">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Username</label>
                                  <input type="text" class="form-control" name="username" value="<?php printf ("%s", $row["username"]); ?>" >
                                </div>
                              </div>
                              <div class="col-6">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Email</label>
                                  <input type="text" class="form-control"  name="email" value="<?php printf ("%s", $row["email"]); ?>" >
                                </div>
                              </div>
                               <div class="col-6">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Contact</label>
                                  <input type="text" class="form-control"  name="contact" value="<?php printf ("%s", $row["contact"]); ?>" >
                                </div>
                              </div>

                               <div class="col-6">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">User Type</label>
                                  <select class="form-control"  name="user_type">
                                   <?php
                                   if ($row['user_type'] == "Regional Admin")
                                   {
                                   	 ?>
                                   <option selected="">Regional Admin</option>
                                   <option>Encoder</option>
                                   <option>Administrator</option>
                                   <?php
                               }
                               else if ($row['user_type'] == "Encoder")
                               	{
                               		?>
                               	   <option selected="">Encoder</option>
                                   <option>Regional Admin</option>
                                   <option>Administrator</option>
                                   <?php
                               }
                               else
                               {
                               	?>
                               	   <option selected="">Administrator</option>
                                   <option>Regional Admin</option>
                                   <option>Encoder</option>
                               <?php
                           }
                           ?>
                               	</select>
                                </div>
                              </div>
                              
                              <div class="col-6">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Choose New Avatar</label>
                                 <input type="file" name="avatar" id="avatar" />
                                </div>
                              </div>
                              </div>
                              </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                              <input type="submit" name="avatar" id="avatar" value="Submit" class="btn btn-primary" /> 
                            </div>
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                      <div class="modal fade" id="delete<?php printf ("%s", $row["user_id"]); ?>" style="margin-left: 30%; margin-top: 20%">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Deactivate Account?</h5>
              
            </div>
            
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> No!</button>
              <a href="delete_user.php? user_id=<?php printf ("%s", $row["user_id"]); ?>"><button type="button" class="btn btn-primary"><i class="fa fa-check"></i> Yes!</button></a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <div class="modal fade" id="password<?php printf ("%s", $row["user_id"]); ?>">
        <div class="modal-dialog modal-sm">
                            <form action="update_password.php"  method="post" id="form1<?php printf ("%s", $row["user_id"]); ?>" enctype="multipart/form-data" name="form1" >
                         <input type="hidden" name="user_idz" value="<?php printf ("%s", $row["user_id"]); ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Change Password</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="row">
                                  <div class="col-12">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Old Password</label>
                                  <input type="password" class="form-control" id="" disabled="" name="full_name" value="**********" >
                                </div>
                              </div>
                                 <div class="col-12">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">New Password</label>
                                  <input type="password" required="" class="form-control" id="" name="npassword" placeholder="Enter New Password .. ">
                                </div>
                              </div>
                                 <div class="col-12">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Confirm Password</label>
                                 <input type="password" required="" class="form-control" id="" name="cpassword" placeholder="Confirm Password .. ">
                                </div>
                              </div>
                              </div>
                              </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                              <input type="submit" name="avatar" id="avatar" value="Submit" class="btn btn-primary" /> 
                            </div>
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
        <!-- /.modal-dialog -->
      </div>
 <script>  
 $(document).ready(function(){  
      $('#insert').click(function(){  
           var image_name = $('#avatar').val();  
           if(image_name == '')  
           {  
                alert("Please Select Image");  
                return false;  
           }  
           else  
           {  
                var extension = $('#avatar').val().split('.').pop().toLowerCase();  
                if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)  
                {  
                     alert('Invalid Image File');  
                     $('#avatar').val('');  
                     return false;  
                }  
           }  
      });  
 });  
 </script>  
          
<?php 
  }   
  
?>
