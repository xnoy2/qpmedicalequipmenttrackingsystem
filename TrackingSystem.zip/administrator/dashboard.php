 <?php
include 'connect.php';
session_start();

if ($_SESSION['user_id'] ==!empty($user_id))
{
  
  header ('location:../index.php');
}
?>
  <?php
  require_once("connect.php");
  

  $user_id = $_SESSION['user_id'];
  $user_type = $_SESSION['user_type'];
  if ($user_type !== "Administrator")
  {
     header ('location:logoutsession.php');
  }
  else
  {
  $sql= "SELECT user_id,full_name,username,password,user_type,contact,email,avatar FROM tbl_user WHERE user_id=? AND user_type='Administrator' ";
              
  $qry=$DbConnect->prepare($sql);
  $qry->bind_result($user_id,$full_name,$username,$password,$user_type,$contact,$email,$avatar);
  $qry->bind_param("s",$user_id);
  $qry->execute();

  while ($qry->fetch())
  { 
    ?>
  
<?php
}
}
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>QP Medical Equipment Tracking System</title>
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">
</head>


<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light" style="background-color: #28a745;">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars" style="color: #fff;"></i></a>
      </li>
    
    </ul>



    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Messages Dropdown Menu -->
      
      <!-- Notifications Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="modal" data-target="#modal-sm" href="#" style="color: #fff;">
          <i class="fa fa-power-off"></i>

          <span class="badge badge-warning navbar-badge"></span>
        </a>  
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button" style="color: #fff;">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>

    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="" class="brand-link">
      <img src="logo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-1" style="
    float: left;
    line-height: .8;
    margin-left: .8rem;
    margin-right: .5rem;
    margin-top: -3px;
    max-height: 33px;
    width: 40px; border-radius: 50%;">
      <span class="brand-text font-weight-light">Tracking System</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
    <?php echo '<img src="data:image/jpeg;png;jpg;base64,'.base64_encode($avatar).'" class="img-square elevation-3" style="width:30px; border-radius:10%;" alt="User Image" >'; ?>
        </div>
        <div class="info">
         <a href="#" class="d-block" style="margin-top: -7px"><?php echo $full_name; ?></a>
         <a href="#" style="color: #239db1; font-size: 15px"><i class="fa fa-circle text-primary" style="font-size: 13px;"></i > <?php echo $user_type; ?></a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item menu-open">
            <a href="dashboard.php" class="nav-link active" style="background-color: #28a745; color: #fff;">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
           <li class="nav-item">
            <a href="medicalequipment.php" class="nav-link">
              <i class="nav-icon fas fa-first-aid"></i>
              <p>
                Medical Equipment
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="movementequipment.php" class="nav-link">
              <i class="nav-icon fas fa-tools"></i>
              <p>
                Movement Equipment
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="imageupload.php" class="nav-link">
              <i class="nav-icon fas fa-image"></i>
              <p>
                Image Upload
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="calibrationreport.php" class="nav-link">
              <i class="nav-icon fas fa-chart-bar"></i>
              <p>
                Calibration Report
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="depreciation_report.php" class="nav-link">
              <i class="nav-icon fas fa-edit"></i>
              <p>
                Depreciation Report
              </p>
            </a>
          </li>
          <li class="nav-header" style="margin-top: -8%; margin-left: 20%; color: #17a2b8; font-weight: 10%;">Management</li>
              <li class="nav-item">
                <a href="brand.php" class="nav-link">
              <i class="nav-icon fas fa-tag"></i>
                  <p>Brand</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="category.php" class="nav-link">
              <i class="nav-icon fas fa-th-large"></i>
                  <p>Category</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="assettype.php" class="nav-link">
              <i class="nav-icon fas fa-hand-holding-usd"></i>
                  <p>Asset Type</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="vendor.php" class="nav-link">
              <i class="nav-icon fas fa-house-user"></i>
                  <p>Vendor Information</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="clinic.php" class="nav-link">
              <i class="nav-icon fas fa-clinic-medical"></i>
                  <p>Clinic Information</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="clinicsection.php" class="nav-link">
              <i class="nav-icon fas fa-clinic-medical"></i>
                  <p>Clinic Section</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="subclinicsection.php" class="nav-link">
              <i class="nav-icon fas fa-clinic-medical"></i>
                  <p>Clinic Sub Section</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="region.php" class="nav-link">
              <i class="nav-icon fas fa-church"></i>
                  <p>Region</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="status.php" class="nav-link">
              <i class="nav-icon fas fa-edit"></i>
                  <p>Item Condition</p>
                </a>
              </li>
              
              <li class="nav-item">
                <a href="uom.php" class="nav-link">
              <i class="nav-icon fas fa-balance-scale-left"></i>
                  <p>UOM</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="manufacturer.php" class="nav-link">
              <i class="nav-icon fas fa-industry"></i>
                  <p>Manufacturer</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="user.php" class="nav-link">
              <i class="nav-icon fas fa-user"></i>
                  <p>User</p>
                </a>
              </li>
         
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
      <div class="modal fade" id="modal-sm" style="margin-left: 30%">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Are you sure you want to log out?</h5>
              
            </div>
            
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> No!</button>
              <a href="logoutsession.php"><button type="button" class="btn btn-primary"><i class="fa fa-check"></i> Yes!</button></a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-4 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?php
                include 'connect.php';
$conn = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
$sql="select count('user_id') from tbl_user where status='1'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);
echo "$row[0]";
mysqli_close($conn);
?>
                </h3>
                <p>Total Active Users</p>
              </div>
              <div class="icon">
                <i class="fa fa-users"></i>
              </div>
              <a href="user.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
            <div class="col-lg-4 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><?php
                include 'connect.php';
$conn = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
$sql="select count('user_id') from tbl_user where status='2'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);
echo "$row[0]";
mysqli_close($conn);
?>
                </h3>
                <p>Total Inactive Users</p>
              </div>
              <div class="icon">
                <i class="fa fa-users"></i>
              </div>
              <a href="user.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-4 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?php
                include 'connect.php';
$conn = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
$sql="select count('equipment_id') from tbl_medical_equipment where status='Approved'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);
echo "$row[0]";
mysqli_close($conn);
?></h3>

                <p>Total Approved Equipment</p>
              </div>
              <div class="icon">
                <i class="fa fa-first-aid"></i>
              </div>
              <a href="medicalequipment.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?php
                include 'connect.php';
$conn = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
$sql="select count('equipment_id') from tbl_medical_equipment where status='Pending'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);
echo "$row[0]";
mysqli_close($conn);
?></h3>

                <p>Total Pending Equipment</p>
              </div>
              <div class="icon">
                <i class="fa fa-first-aid"></i>
              </div>
              <a href="medicalequipment.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><?php
                include 'connect.php';
$conn = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
$sql="select count('equipment_id') from tbl_medical_equipment where status='Rejected'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);
echo "$row[0]";
mysqli_close($conn);
?></h3>

                <p>Total Rejected Equipment</p>
              </div>
              <div class="icon">
                <i class="fa fa-first-aid"></i>
              </div>
              <a href="medicalequipment_rejected.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?php
                include 'connect.php';
$conn = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
$sql="select count('calibration_id') from tbl_calibration_report where status='Approved'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);
echo "$row[0]";
mysqli_close($conn);
?></h3>

                <p>Total Approved Calibration Report</p>
              </div>
              <div class="icon">
                <i class="fa fa-chart-bar"></i>
              </div>
              <a href="calibrationreport.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
           <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?php
                include 'connect.php';
$conn = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
$sql="select count('calibration_id') from tbl_calibration_report where status='Pending'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);
echo "$row[0]";
mysqli_close($conn);
?></h3>

                <p>Total Pending  Calibration Report</p>
              </div>
              <div class="icon">
                <i class="fa fa-chart-bar"></i>
              </div>
              <a href="calibrationreport_pending.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <!-- ./col -->
        </div>
        <!-- /.row -->
        <!-- Main row -->
        <div class="row" style="margin-left: 33.2%">
          <a href="downloaddatabase.php" ><button class="btn btn-primary btn-lg" style="height: 160%"><i class="fa fa-database">
<?php
$con = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");  


if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit;
}

// Return name of current default database
if ($result = mysqli_query($con, "SELECT DATABASE()")) {
  $row = mysqli_fetch_row($result);
  echo  "".$row[0];
  mysqli_free_result($result);

}

// Close connection
mysqli_close($con);
?>
</i></button></a>
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
 <p style="margin-left: 41%; margin-top: 30px">Click here <i class="fa fa-arrow-up"></i> to Backup Database!</p>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <strong>Footer <a href="" style="color: #3d9970">Medical Equipment Tracking System</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Footer</b>
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<!-- Sparkline -->
<script src="plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<!-- jQuery Knob Chart -->
<script src="plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="plugins/moment/moment.min.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard.js"></script>
</body>
</html>
