<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
		<script type="text/javascript" src="dist/sweetalert-dev.js"></script>
	</head>
	

	<body>
		
	</body>

</html>
<?php

require_once 'connect.php';

$calibration_id =$_GET['calibration_id'];

$sql="DELETE FROM tbl_calibration_report WHERE calibration_id=?";
$qry=$DbConnect->prepare($sql);
$qry->bind_param("s",$calibration_id);
if($qry->execute()==true)
{
	succ();
	
} 
else
{
	err();

}
function succ()
		{
			echo '<script>
			swal({
				title: "Deleted Successfuly",
				type: "success",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "calibrationreport.php ";
			});
			</script>';
		}
		function err()
		{
			echo '<script>
			swal({
				title: "ERROR!!",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "calibrationreport.php ";
			});
			</script>';
		}