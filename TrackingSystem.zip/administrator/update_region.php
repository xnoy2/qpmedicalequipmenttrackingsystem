
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
        <script type="text/javascript" src="dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>

</html>
<?php
require_once 'connect.php';
$region_id= isset($_POST['region_idz'])? $_POST['region_idz']:"";
$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
$region_name=$_POST['region_name'];
        $sql1 = "SELECT * FROM tbl_medical_equipment WHERE region_id=?";
            $qry1 =$DbConnect->prepare($sql1);
            $qry1->bind_param("s",$region_id);
            $qry1->execute();
            $qry1->store_result();
            $qry1->fetch();
            if ($qry1->num_rows()<=0)
                {
if (!empty($region_name))
{
    $sql = "UPDATE tbl_region SET region_name=?, user_id=? WHERE region_id=?";
    $qry =$DbConnect->prepare($sql);
    $qry->bind_param("sss",$region_name,$user_id,$region_id);
    if ($qry->execute())
    {
     succ();    
    }
}
else 
{
    err();
}
}
else
{
    err2();
}
function succ()
        {
            echo '<script>
            swal({
                title: "Updated Successfully",
                type: "success",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "region.php ";
            });
            </script>';
        }
        function err()
        {
            echo '<script>
            swal({
                title: "Error!!...",
                type: "error",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "region.php ";
            });
            </script>';
        }
                                function err2()
        {
            echo '<script>
            swal({
                title: "Cant Update this item. It might already exist in equipment record",
                type: "warning",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "region.php ";
            });
            </script>';
        }
        ?>