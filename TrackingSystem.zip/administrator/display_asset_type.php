
<?php
 require_once("connect.php");
  $user_id = $_SESSION['user_id'];
  $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");  
  $sql="SELECT tbl_asset_type.asset_type_id,tbl_asset_type.type_name,tbl_category.category_id, tbl_category.category_name, tbl_user.user_id,tbl_user.full_name FROM tbl_asset_type INNER JOIN tbl_user ON tbl_asset_type.user_id=tbl_user.user_id INNER JOIN tbl_category ON tbl_asset_type.category_id=tbl_category.category_id;";
  $qry=$DbConnect->prepare($sql);
  $qry->bind_result($asset_type_id,$type_name,$category_id,$category_name,$user_id,$full_name);
$qry->execute();
$result = mysqli_query($connect, $sql);  

while($row = mysqli_fetch_array($result))
  {
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_id,full_name FROM tbl_user WHERE user_id=?";
      ?>

      <tr>
      
         <td><?php printf ("%s", $row["type_name"]); ?> </td>
         <td><?php printf ("%s", $row["category_name"]); ?> </td>
         <td><?php printf ("%s", $row["full_name"]); ?> </td>
         <td>
        <button type='button' class='btn btn-info btn-xs' data-toggle='modal' data-target='#update<?php printf ("%s", $row["asset_type_id"]); ?>'><i class='fa fa-pencil-alt'></i> 
              </button>
          <button type='button' class='btn btn-xs btn-danger ' data-toggle='modal' data-target='#delete<?php printf ("%s", $row["asset_type_id"]); ?>'><i class="fa fa-trash "></i>  </button>
        </td>
              
      </tr>
      
                  <div class="modal fade" id="update<?php printf ("%s", $row["asset_type_id"]); ?>">
                        <div class="modal-dialog modal-sm">
                            <form action="update_asset_type.php" method="post" id="form1<?php printf ("%s", $row["asset_type_id"]); ?>"  name="form1">
                         <input type="hidden" name="asset_type_idz" value="<?php printf ("%s", $row["asset_type_id"]); ?>">
                         <input type="hidden" name="user_idz" value="<?php printf ("%s", $row["user_id"]); ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Update Asset Type</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Asset Type</label>
                                  <input type="text" class="form-control" id="" name="type_name"  value="<?php printf ("%s", $row["type_name"]); ?>">
                                </div>
                               <div class="form-group">
                                  <label>Category</label>
                                  <select class="form-control select2" name="category_id">
                                    <option selected=""  value=<?php printf ("%s", $row["category_id"]); ?>><?php printf ("%s", $row["category_name"]); ?></option>
                                    <?php
                                   include 'connect.php';

                                    $sql1="SELECT tbl_category.category_id,tbl_category.category_name FROM tbl_category";
                                    $qry1=$DbConnect->prepare($sql1);
                                    $qry1->bind_result($category_id,$category_name);
                                    $qry1->execute();

                                    while ($qry1->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $category_id ?>"><?php echo $category_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                              <button type="submit" onclick="form1<?php printf ("%s", $row["asset_type_id"]); ?>.submit();" form="form1" class="btn btn-primary"><i class="fa fa-check"></i> Update</button>
                            </div>
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                      <div class="modal fade" id="delete<?php printf ("%s", $row["asset_type_id"]); ?>" style="margin-left: 30%; margin-top: 20%">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Are you sure you want delete this data?</h5>
              
            </div>
            
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> No!</button>
              <a href="delete_asset_type.php? asset_type_id=<?php printf ("%s", $row["asset_type_id"]); ?>"><button type="button" class="btn btn-primary"><i class="fa fa-check"></i> Yes!</button></a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
         

        
          
<?php 
  }   
  
?>
