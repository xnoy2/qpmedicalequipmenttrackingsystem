
<?php
  require_once("connect.php");
  $user_id = $_SESSION['user_id'];
  $sql="SELECT tbl_manufacturer.manufacturer_id,tbl_manufacturer.manufacturer_name,tbl_manufacturer.manufacturer_address,tbl_manufacturer.manufacturer_contact,tbl_user.user_id,tbl_user.full_name FROM tbl_manufacturer INNER JOIN tbl_user ON tbl_manufacturer.user_id=tbl_user.user_id";
  $qry=$DbConnect->prepare($sql);
  $qry->bind_result($manufacturer_id,$manufacturer_name,$manufacturer_address,$manufacturer_contact,$user_id,$full_name);
  $qry->execute();

  while ($qry->fetch())
  {
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_id,full_name FROM tbl_user WHERE user_id=?";
      ?>

      <tr>
      
        <td><b style="color: darkblue"><?php echo $manufacturer_name; ?></b> </td>
        <td><?php echo $manufacturer_contact; ?> </td>
        <td><?php echo $manufacturer_address; ?> </td>
        <td><?php echo $full_name; ?> </td>
         <td>
        <button type='button' class='btn btn-info btn-xs' data-toggle='modal' data-target='#update<?php echo $manufacturer_id; ?>'><i class='fa fa-pencil-alt'></i> 
              </button>
          <button type='button' class='btn btn-xs btn-danger ' data-toggle='modal' data-target='#delete<?php echo $manufacturer_id; ?>'><i class="fa fa-trash "></i>  </button>
        </td>
              
      </tr>
      
                  <div class="modal fade" id="update<?php echo $manufacturer_id;?>">
                        <div class="modal-dialog modal-sm">
                            <form action="update_manufacturer.php" method="post" id="form1<?php echo $manufacturer_id; ?>"  name="form1">
                         <input type="hidden" name="manufacturer_idz" value="<?php echo $manufacturer_id; ?>">
                         <input type="hidden" name="user_idz" value="<?php echo $user_id; ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Update Manufacturer</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Manufacturer</label>
                                  <input type="text" class="form-control" id="" name="manufacturer_name"  value="<?php echo $manufacturer_name; ?>">
                                </div>
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Contact</label>
                                  <input type="text" class="form-control" id="" name="manufacturer_contact" value="<?php echo $manufacturer_contact; ?>">
                                </div>
                              <div class="form-group">
                                  <label for="exampleInputEmail1">Address</label>
                                  <input type="text" class="form-control" id="" name="manufacturer_address" value="<?php echo $manufacturer_address; ?>" >
                                </div>
                              </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                              <button type="submit" onclick="form1<?php echo $manufacturer_id; ?>.submit();" form="form1" class="btn btn-primary"><i class="fa fa-check"></i> Update</button>
                            </div>
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                      <div class="modal fade" id="delete<?php echo $manufacturer_id;?>" style="margin-left: 30%; margin-top: 20%">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Are you sure you want delete this data?</h5>
              
            </div>
            
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> No!</button>
              <a href="delete_manufacturer.php? manufacturer_id=<?php echo $manufacturer_id; ?>"><button type="button" class="btn btn-primary"><i class="fa fa-check"></i> Yes!</button></a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
         

        
          
<?php 
  }   
  
?>
