
<?php
  require_once("connect.php");
  $user_id = $_SESSION['user_id'];
  date_default_timezone_set("Asia/Manila");
  $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");  
$user_id = $_SESSION['user_id'];
  $sql="SELECT tbl_movement_equipment.movement_id, tbl_movement_equipment.equipment_id, tbl_medical_equipment.equipment_name, tbl_movement_equipment.transfer_from, tbl_movement_equipment.transfer_froms, tbl_movement_equipment.date_of_transfer, tbl_movement_equipment.remarks, tbl_user.user_id, tbl_user.full_name FROM tbl_movement_equipment INNER JOIN tbl_medical_equipment ON tbl_movement_equipment.equipment_id = tbl_medical_equipment.equipment_id INNER JOIN tbl_user ON tbl_movement_equipment.user_id = tbl_user.user_id GROUP BY tbl_movement_equipment.movement_id, tbl_movement_equipment.equipment_id, tbl_medical_equipment.equipment_name, tbl_movement_equipment.transfer_from, tbl_movement_equipment.transfer_froms, tbl_movement_equipment.date_of_transfer, tbl_movement_equipment.remarks, tbl_user.user_id, tbl_user.full_name";
  $qry=$DbConnect->prepare($sql);
  $qry->bind_result($movement_id,$equipment_id,$equipment_name,$transfer_from,$transfer_froms,$date_of_transfer,$remarks,$user_id,$full_name);
$qry->execute();
$result = mysqli_query($connect, $sql);  
while($row = mysqli_fetch_array($result))
  { 
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_id,full_name FROM tbl_user WHERE user_id=?";
    ?>

      <tr>
      
        <td><b style="color: blue;"><?php printf ("%s", $row["equipment_name"]); ?> </b></td>
        <td><?php printf ("%s", $row["transfer_from"]); ?> </td>
        <td><?php printf ("%s", $row["transfer_froms"]); ?> </td>
        <td><?php $date_of_transfer=strtotime($row['date_of_transfer']);
          echo date("M-d-Y",$date_of_transfer)?></td>
        <td><?php printf ("%s", $row["remarks"]); ?></td>
        <td><?php printf ("%s", $row["full_name"]); ?> </td>
         <td>

        <button type='button' class='btn btn-info btn-xs' data-toggle='modal' data-target='#update<?php printf ("%s", $row["movement_id"]); ?>'><i class='fa fa-pencil-alt'></i> 
              </button>
          <button type='button' class='btn btn-xs btn-danger ' data-toggle='modal' data-target='#delete<?php printf ("%s", $row["movement_id"]); ?>'><i class="fa fa-trash "></i>  </button>
        </td>
              
      </tr>
      
            
                  <div class="modal fade" id="update<?php printf ("%s", $row["movement_id"]); ?>">
                        <div class="modal-dialog modal-md">
                            <form action="update_movement.php" method="post" id="form1<?php printf ("%s", $row["movement_id"]); ?>" name="form1">
                          <input type="hidden" name="movement_idz" value="<?php printf ("%s", $row["movement_id"]); ?>">
                            <input type="hidden" name="user_idz" value="<?php echo $user_id; ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Update Movement Equipment</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="row">
                                  <div class="col-12">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Equipment</label>
                                  <select class="form-control select2" name="equipment_id">
                                  <option selected="" value="<?php printf ("%s", $row["equipment_id"]); ?>"><?php printf ("%s", $row["equipment_name"]); ?></option>
                                    <?php
                                    include 'connect.php';
                                    $sql="SELECT tbl_medical_equipment.equipment_id,tbl_medical_equipment.equipment_name FROM tbl_medical_equipment WHERE tbl_medical_equipment.status = 'Approved' ORDER BY tbl_medical_equipment.equipment_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($equipment_id,$equipment_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $equipment_id ?>"><?php echo $equipment_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-6">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Transfer From : </label>
                                  <select class="form-control select2" name="transfer_from">
                                  <option selected="" value="<?php printf ("%s", $row["transfer_from"]); ?>"><?php printf ("%s", $row["transfer_from"]); ?></option>
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_section.clinic_section_id,tbl_section.section_name FROM tbl_section";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($clinic_section_id,$section_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option><?php echo $section_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-6">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Transfer To : </label>
                                  <select class="form-control select2" name="transfer_froms">
                                  <option selected="" value="<?php printf ("%s", $row["transfer_froms"]); ?>"><?php printf ("%s", $row["transfer_froms"]); ?></option>
                                    <?php
                                    require_once("connect.php");
                                    $sql="SELECT tbl_section.clinic_section_id,tbl_section.section_name FROM tbl_section";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($clinic_section_id,$section_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option><?php echo $section_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-12">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Remarks</label>
                                  <textarea class="form-control" rows="3" name="remarks"  placeholder="Enter ..."><?php printf ("%s", $row["remarks"]); ?></textarea>
                                </div>
                              </div>
                               </div>
                              </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                            <button type="submit" onclick="form1<?php printf ("%s", $row["movement_id"]); ?>.submit();" form="form1" class="btn btn-primary"><i class="fa fa-check"></i> Update</button>                            
                            </div>
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                      <div class="modal fade" id="delete<?php printf ("%s", $row["movement_id"]); ?>" style="margin-left: 30%; margin-top: 20%">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Are you sure you want delete this data?</h5>
              
            </div>
            
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> No!</button>
              <a href="delete_movement.php? movement_id=<?php printf ("%s", $row["movement_id"]); ?>"><button type="button" class="btn btn-primary"><i class="fa fa-check"></i> Yes!</button></a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
         
        
          
<?php 
  }   
  
?>
