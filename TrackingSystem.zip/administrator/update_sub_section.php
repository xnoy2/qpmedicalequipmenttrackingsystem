
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
        <script type="text/javascript" src="dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>

</html>
<?php
require_once 'connect.php';
$sub_section_id= isset($_POST['sub_section_idz'])? $_POST['sub_section_idz']:"";
$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
$sub_section_name=$_POST['sub_section_name'];
        $sql1 = "SELECT * FROM tbl_medical_equipment WHERE sub_section_id=?";
            $qry1 =$DbConnect->prepare($sql1);
            $qry1->bind_param("s",$sub_section_id);
            $qry1->execute();
            $qry1->store_result();
            $qry1->fetch();
            if ($qry1->num_rows()<=0)
                {
if (!empty($sub_section_name))
{
    $sql = "UPDATE tbl_sub_section SET sub_section_name=?, user_id=? WHERE sub_section_id=?";
    $qry =$DbConnect->prepare($sql);
    $qry->bind_param("sss",$sub_section_name,$user_id,$sub_section_id);
    if ($qry->execute())
    {
     succ();    
    }
}
else 
{
    err();
}
}
else
{
    err2();
}
function succ()
        {
            echo '<script>
            swal({
                title: "Updated Successfully",
                type: "success",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "subclinicsection.php ";
            });
            </script>';
        }
        function err()
        {
            echo '<script>
            swal({
                title: "Error!!...",
                type: "error",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "subclinicsection.php ";
            });
            </script>';
        }
         function err2()
        {
            echo '<script>
            swal({
                title: "Cant Update this item. It might already exist in equipment record",
                type: "warning",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "subclinicsection.php ";
            });
            </script>';
        }
        ?>