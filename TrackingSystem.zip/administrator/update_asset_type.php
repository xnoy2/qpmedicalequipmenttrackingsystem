
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
        <script type="text/javascript" src="dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>

</html>
<?php
require_once 'connect.php';
$asset_type_id= isset($_POST['asset_type_idz'])? $_POST['asset_type_idz']:"";
$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
$type_name=$_POST['type_name'];
$category_id = $_POST['category_id'];
        $sql1 = "SELECT * FROM tbl_medical_equipment WHERE asset_type_id=?";
            $qry1 =$DbConnect->prepare($sql1);
            $qry1->bind_param("s",$asset_type_id);
            $qry1->execute();
            $qry1->store_result();
            $qry1->fetch();
            if ($qry1->num_rows()<=0)
                {
if (!empty($type_name))
{
    $sql = "UPDATE tbl_asset_type SET type_name=?, category_id=?, user_id=? WHERE asset_type_id=?";
    $qry =$DbConnect->prepare($sql);
    $qry->bind_param("ssss",$type_name,$category_id,$user_id,$asset_type_id);
    if ($qry->execute())
    {
     succ();    
    }
}
else 
{
    err();
}
}
else
{
    err2();
}
function succ()
        {
            echo '<script>
            swal({
                title: "Updated Successfully",
                type: "success",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "assettype.php ";
            });
            </script>';
        }
        function err()
        {
            echo '<script>
            swal({
                title: "Error!!...",
                type: "error",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "assettype.php ";
            });
            </script>';
        }
        function err2()
        {
            echo '<script>
            swal({
                title: "Cant Update this item. It might already exist in equipment record",
                type: "warning",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "assettype.php ";
            });
            </script>';
        }
        ?>