<!DOCTYPE html>
<html>
  <head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
    <script type="text/javascript" src="dist/sweetalert-dev.js"></script>
  </head>
  

  <body>
    
  </body>

</html>

 <?php
  include ("connect.php");

  $uom_name = $_POST['uom_name'];
  $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $sql1 = "SELECT * FROM tbl_uom WHERE uom_name=?";
      $qry1 =$DbConnect->prepare($sql1);
      $qry1->bind_param("s",$uom_name);
      $qry1->execute();
      $qry1->store_result();
      $qry1->fetch();
      if ($qry1->num_rows()<=0)
        {
  if (!empty($uom_name))
    {
      $uom_name = $_POST['uom_name'];
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $sql="INSERT INTO tbl_uom (uom_name,user_id) VALUES (?,?)";
      $qry=$DbConnect->prepare($sql);
      $qry->bind_param("ss", $uom_name, $user_id);
      if ($qry->execute())
      {
         succ();

      }
      else
    {
      error2();
    }
    }
    else
    {
      error2();
    }
  }
  else
  {
    err2();
  }
    function succ()
    {
      echo '<script>
      swal({
        title: "Added Successfully",
        type: "success",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "uom.php ";
      });
      </script>';
    }
    function error2()
    {
      echo '<script>
      swal({
        title: "Error!!!..",
        type: "error",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "uom.php ";
      });
      </script>';
    }
            function err2()
    {
      echo '<script>
      swal({
        title: "UOM name Already Exist",
        type: "error",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "uom.php ";
      });
      </script>';
    }
  
?>
  
?>