<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
		<script type="text/javascript" src="dist/sweetalert-dev.js"></script>
	</head>
	

	<body>
		
	</body>

</html>

 <?php
	include ("connect.php");

	$region_name = $_POST['region_name'];
	$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
	$sql1 = "SELECT * FROM tbl_region WHERE region_name=?";
			$qry1 =$DbConnect->prepare($sql1);
			$qry1->bind_param("s",$region_name);
			$qry1->execute();
			$qry1->store_result();
			$qry1->fetch();
			if ($qry1->num_rows()<=0)
				{
	if (!empty($region_name))
		{
			$region_name = $_POST['region_name'];
			$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
			$sql="INSERT INTO tbl_region (region_name,user_id) VALUES (?,?)";
			$qry=$DbConnect->prepare($sql);
			$qry->bind_param("ss", $region_name, $user_id);
			if ($qry->execute())
			{
				 succ();

			}
			else
		{
			error2();
		}
		}
		else
		{
			error2();
		}
	}
	else
	{
		err2();
	}
		function succ()
		{
			echo '<script>
			swal({
				title: "Added Successfully",
				type: "success",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "region.php ";
			});
			</script>';
		}
		function error2()
		{
			echo '<script>
			swal({
				title: "Error!!!..",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "region.php ";
			});
			</script>';
		}
	
				function err2()
		{
			echo '<script>
			swal({
				title: "Region name Already Exist",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "region.php ";
			});
			</script>';
		}
	
?>