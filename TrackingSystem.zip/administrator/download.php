<?php
$conn = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");  
include 'connect.php';
if (isset($_GET['file_id']))
{
    $calibration_id = $_GET['file_id'];

    $sql = "SELECT * FROM tbl_calibration_report WHERE calibration_id=$calibration_id";
    $result = mysqli_query($conn,$sql);
    $file = mysqli_fetch_assoc($result);
    $filepatch = 'Uploaded/'.$file['file_uploaded'];

    if (file_exists($filepatch))
    {
        header('Content-Type: application/octet-stream');

        header('Content-Description: File Transfer');

        header('Content-Disposition: attachment; filename=' .
        basename($filepatch));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma:public');
        header('Content-Length:' .filesize('Uploaded/' .$file['file_uploaded']));
        readfile('Uploaded/' .$file['file_uploaded']);
    }
}
?>