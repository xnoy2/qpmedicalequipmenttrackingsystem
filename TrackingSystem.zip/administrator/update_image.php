
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
        <script type="text/javascript" src="dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>
 <script>  
 $(document).ready(function(){  
      $('#insert').click(function(){  
           var image_name = $('#avatar').val();  
           if(image_name == '')  
           {  
                alert("Please Select Image");  
                return false;  
           }  
           else  
           {  
                var extension = $('#avatar').val().split('.').pop().toLowerCase();  
                if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)  
                {  
                     alert('Invalid Image File');  
                     $('#avatar').val('');  
                     return false;  
                }  
           }  
      });  
 });  
 </script>   
</html>
<?php
include 'connect.php';
 $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");  

     if($_FILES['image_file']['name'] !== "")
     {
      $image_id= isset($_POST['image_idz'])? $_POST['image_idz']:"";
      $image_name = $_POST['image_name'];  
      $description = $_POST['description'];  
      $equipment_id = $_POST['equipment_id'];
      $image_file = addslashes(file_get_contents($_FILES["image_file"]["tmp_name"]));
      $query = ("UPDATE tbl_images SET equipment_id='".$equipment_id."', image_name='".$image_name."', image_file='".$image_file."', description='".$description."' WHERE image_id = '".$image_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
        error2();
      }
    }
    else
    {
      $image_id= isset($_POST['image_idz'])? $_POST['image_idz']:"";
      $image_name = $_POST['image_name'];  
      $description = $_POST['description'];  
      $equipment_id = $_POST['equipment_id'];
      $query = ("UPDATE tbl_images SET equipment_id='".$equipment_id."', image_name='".$image_name."', description='".$description."' WHERE image_id = '".$image_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
        error2();
      }
    }
  function succ()
    {
      echo '<script>
      swal({
        title: "Updated Successfully",
        type: "success",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "imageupload.php ";
      });
      </script>';
    }
    function error2()
    {
      echo '<script>
      swal({
        title: "Error!!!..",
        type: "error",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "imageupload.php ";
      });
      </script>';
    }  
 ?>  
