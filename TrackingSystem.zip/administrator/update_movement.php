
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
        <script type="text/javascript" src="dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body> 
</html>
<?php
include 'connect.php';
 $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");
      date_default_timezone_set("Asia/Manila");
      $movement_id= isset($_POST['movement_idz'])? $_POST['movement_idz']:"";
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $equipment_id = $_POST['equipment_id'];
      $transfer_from= $_POST['transfer_from'];
      $transfer_froms = $_POST['transfer_froms'];
      $remarks = $_POST['remarks'];
      $date_of_transfer  = date("Y-m-d");
    $query = ("UPDATE tbl_movement_equipment SET equipment_id='".$equipment_id."', transfer_from='".$transfer_from."', transfer_froms='".$transfer_froms."', date_of_transfer='".$date_of_transfer."', remarks='".$remarks."', user_id='".$user_id."' WHERE movement_id='".$movement_id."'");
    if(mysqli_query($connect, $query))
      {
     succ();
    }
      else
      {
        error2();
      }
    
  function succ()
    {
      echo '<script>
      swal({
        title: "Updated Successfully",
        type: "success",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "movementequipment.php ";
      });
      </script>';
    }
    function error2()
    {
      echo '<script>
      swal({
        title: "Error!!!..",
        type: "error",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "movementequipment.php ";
      });
      </script>';
    }  
 ?>  
