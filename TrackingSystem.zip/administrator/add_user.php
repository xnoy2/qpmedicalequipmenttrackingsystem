  <!DOCTYPE html>
<html>
  <head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
    <script type="text/javascript" src="dist/sweetalert-dev.js"></script>
  </head>
  

  <body>
    
  </body>

</html>

   
  <?php  
 $connect = mysqli_connect("localhost", "root", "root", "medicalequipmenttrackingsystemdb");  
 if(isset($_POST["avatar"]))  
 {    $full_name = $_POST['full_name'];
      $email = $_POST['email'];  
      $contact = $_POST['contact'];  
      $username = $_POST['username'];  
      $user_type = $_POST['user_type'];
      $avatar = addslashes(file_get_contents($_FILES["avatar"]["tmp_name"]));
      $password = $_POST['password']; 
      $passwordmd5 = md5($password); 
      $status = '1';
     
            $query = "INSERT INTO tbl_user(full_name,email,contact,username,password,user_type,avatar,status) VALUES ('$full_name','$email','$contact','$username','$passwordmd5','$user_type','$avatar',$status)";  
      if(mysqli_query($connect, $query))  
      {  
       succ();
     }
    }
    else
  {
  error2();
}
  function succ()
    {
      echo '<script>
      swal({
        title: "Added Successfully",
        type: "success",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "user.php ";
      });
      </script>';
    }
    function error2()
    {
      echo '<script>
      swal({
        title: "Error!!!..",
        type: "error",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "user.php ";
      });
      </script>';
    }  
 ?>  
